using UnityEngine;

namespace LethalMaze
{
    public sealed class LaserTrap : MonoBehaviour
    {
        private enum State { Idle, Charging, Firing, Cooldown }

        private LevelRuntime level;
        private LaserData data;
        private LineRenderer line;
        private State state;
        private float timer;
        private Vector2 targetSim;
        private Vector2 beamEndSim;

        public void Init(LevelRuntime runtime, LaserData laserData)
        {
            level = runtime;
            data = laserData;
            targetSim = OriginSim;
            beamEndSim = OriginSim;
        }

        private Vector2 OriginSim => LevelRuntime.WorldToSimPoint(transform.position);

        private void Awake()
        {
            line = gameObject.AddComponent<LineRenderer>();
            line.positionCount = 2;
            line.startWidth = 0.035f;
            line.endWidth = 0.035f;
            line.material = new Material(Shader.Find("Sprites/Default"));
            line.startColor = new Color(1f, 0.1f, 0.25f, 0.95f);
            line.endColor = line.startColor;
            line.enabled = false;
        }

        private void Update()
        {
            var player = level.PlayerTransform ? level.PlayerTransform.GetComponent<MoonPlayerController>() : null;
            if (!player) return;

            var playerSim = LevelRuntime.WorldToSimPoint(level.PlayerTransform.position);
            var canSee = CanSee(playerSim);

            if (state == State.Idle && canSee)
            {
                state = State.Charging;
                timer = data.chargeSeconds;
                targetSim = playerSim;
                level.ShowMessage("\u041b\u0430\u0437\u0435\u0440 \u0446\u0435\u043b\u0438\u0442\u0441\u044f \u0441 \u0437\u0430\u0434\u0435\u0440\u0436\u043a\u043e\u0439. \u0414\u0432\u0438\u0433\u0430\u0439\u0441\u044f.");
            }

            if (state == State.Charging)
            {
                targetSim = playerSim;
                timer -= Time.deltaTime;
                DrawLine(targetSim, new Color(1f, 0.85f, 0.1f, 0.5f));
                if (timer <= 0f)
                {
                    state = State.Firing;
                    timer = data.fireSeconds;
                    var direction = (targetSim - OriginSim).normalized;
                    beamEndSim = level.RaycastSolid(OriginSim, direction, data.radiusTiles);
                }
            }
            else if (state == State.Firing)
            {
                DrawLine(beamEndSim, new Color(1f, 0.05f, 0.22f, 1f));
                if (BeamHits(player.SimHurtbox)) player.Die();
                timer -= Time.deltaTime;
                if (timer <= 0f)
                {
                    state = State.Cooldown;
                    timer = data.cooldownSeconds;
                    line.enabled = false;
                }
            }
            else if (state == State.Cooldown)
            {
                timer -= Time.deltaTime;
                if (timer <= 0f) state = State.Idle;
            }
        }

        private bool CanSee(Vector2 playerSim)
        {
            var origin = OriginSim;
            var distance = Vector2.Distance(origin, playerSim);
            if (distance > data.radiusTiles) return false;
            var direction = (playerSim - origin).normalized;
            var end = level.RaycastSolid(origin, direction, distance);
            return Vector2.Distance(end, origin) >= distance - 0.05f;
        }

        private bool BeamHits(Rect hurtbox)
        {
            var origin = OriginSim;
            var beam = beamEndSim - origin;
            var length = beam.magnitude;
            if (length <= 0.001f) return false;

            var center = hurtbox.center;
            var projection = Vector2.Dot(center - origin, beam.normalized);
            if (projection < 0f || projection > length) return false;

            var closest = origin + beam.normalized * projection;
            return Vector2.Distance(center, closest) < 8f / LevelRuntime.SourcePixelsPerTile;
        }

        private void DrawLine(Vector2 simPoint, Color color)
        {
            line.enabled = true;
            line.startColor = color;
            line.endColor = color;
            line.SetPosition(0, SimPointToWorld(OriginSim));
            line.SetPosition(1, SimPointToWorld(simPoint));
        }

        private static Vector3 SimPointToWorld(Vector2 sim)
        {
            return new Vector3(sim.x, -sim.y, 0f);
        }
    }
}
