using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace LethalMaze
{
    public sealed class LevelRuntime : MonoBehaviour
    {
        public Transform PlayerTransform { get; private set; }
        public event Action Won;

        public const float SourcePixelsPerTile = 32f;
        public const float TileSize = 1f;
        public const float PlayerWidth = 22f / SourcePixelsPerTile;
        public const float PlayerHeight = 27f / SourcePixelsPerTile;

        private const int CanvasWidth = 960;
        private const int CanvasHeight = 576;
        private const int TilePx = 32;
        private const int DeathFreezeFrames = 26;
        private const float RespawnSeconds = 0.56f;

        private static readonly Color32 Background = C("111820");
        private static readonly Color32 Wall = C("26364A");
        private static readonly Color32 WallLight = C("344961");
        private static readonly Color32 WallDark = C("1A2534");
        private static readonly Color32 Shadow = C("05070A");
        private static readonly Color32 Spike = C("FF4C6A");
        private static readonly Color32 PlayerColor = C("71F79F");
        private static readonly Color32 PlayerLight = C("D6FFE3");
        private static readonly Color32 Key = C("52EADC");
        private static readonly Color32 Coin = C("FFD15C");
        private static readonly Color32 Saw = C("EEF4FF");
        private static readonly Color32 Steel = C("7B8EA7");
        private static readonly Color32 Muted = C("B8C6D6");
        private static readonly Color32 Black = C("020406");
        private static readonly Color32 RobotEye = C("FFD15C");
        private static readonly Color32 Flier = C("B583FF");

        private readonly string[] map =
        {
            "########################################",
            "###########################.....########",
            "###############....########.....########",
            "#########....#..##..............########",
            "#########....#..##.....................#",
            "#########.D..G.........................#",
            "###########################............#",
            "#........###.....###.....##.....####...#",
            "#....###.###.###.....###.##.###.####...#",
            "#....###.###.###.....###.##.###.####.#.#",
            "#.M..###.###.###.....###.##.###.####.#.#",
            "#........................##.....####.#.#",
            "########.###.###.###.###.##.###.####.#.#",
            "########.###.###.###.###.##.###.####...#",
            "########.###.###.###.###.##.###...##.M.#",
            "########..........................##...#",
            "########.###.#####.....#################",
            "########.###.#####S.M.S#################",
            "########.###.###########################",
            "########......................##########",
            "########...................P..##########",
            "###############.........################",
            "########################################",
            "########################################",
            "########################################"
        };

        private readonly List<RectPx> solids = new List<RectPx>();
        private readonly List<CoinData> requiredCoins = new List<CoinData>();
        private readonly List<TextZoneDataPx> textZones = new List<TextZoneDataPx>();
        private readonly List<FlierDataPx> fliers = new List<FlierDataPx>();
        private readonly List<LaserDataPx> lasers = new List<LaserDataPx>();
        private readonly List<ParticleData> particles = new List<ParticleData>();

        private Texture2D texture;
        private Color32[] pixels;
        private RawImage screenImage;
        private Text messageText;
        private Text deathsText;
        private Text timerText;
        private PlayerData player;
        private RobotDataPx robot;
        private RectPx door;
        private RectPx doorHitbox;
        private RectPx gate;
        private Vector2 spawn;
        private float cameraX;
        private float cameraY;
        private int cameraShake;
        private float startedAt;
        private float respawnTimer;
        private float lastNow;
        private int deaths;
        private int freezeFrames;
        private int frame;
        private int requiredCoinCount;
        private bool gateOpen;
        private bool playing;
        private bool paused;
        private bool jumpPressed;

        private PhysicsProfile physics;

        public void Build(Text uiMessage)
        {
            Build(uiMessage, null, null, null);
        }

        public void Build(Text uiMessage, Text uiDeaths, Text uiTimer)
        {
            Build(uiMessage, uiDeaths, uiTimer, null);
        }

        public void Build(Text uiMessage, Text uiDeaths, Text uiTimer, RawImage image)
        {
            messageText = uiMessage;
            deathsText = uiDeaths;
            timerText = uiTimer;
            screenImage = image;
            EnsureTexture();
            deaths = 0;
            startedAt = Time.time;
            playing = true;
            paused = false;
            BuildLevel();
            ShowMessage("Эти роботы что-то знают.");
            UpdateStats();
            Render();
        }

        private void EnsureTexture()
        {
            if (texture != null) return;
            texture = new Texture2D(CanvasWidth, CanvasHeight, TextureFormat.RGBA32, false);
            texture.filterMode = FilterMode.Point;
            texture.wrapMode = TextureWrapMode.Clamp;
            pixels = new Color32[CanvasWidth * CanvasHeight];
            if (screenImage != null)
            {
                screenImage.texture = texture;
                screenImage.uvRect = new Rect(0f, 1f, 1f, -1f);
            }
        }

        private void BuildLevel()
        {
            solids.Clear();
            requiredCoins.Clear();
            textZones.Clear();
            fliers.Clear();
            lasers.Clear();
            particles.Clear();
            requiredCoinCount = 0;
            gateOpen = false;
            freezeFrames = 0;
            respawnTimer = 0f;
            frame = 0;
            physics = PhysicsProfile.LevelThreeMoon();

            for (var ty = 0; ty < map.Length; ty++)
            {
                for (var tx = 0; tx < map[ty].Length; tx++)
                {
                    var tile = map[ty][tx];
                    var x = tx * TilePx;
                    var y = ty * TilePx;
                    if (tile == '#') solids.Add(new RectPx(x, y, TilePx, TilePx, '#', tx, ty));
                    if (tile == 'P') spawn = new Vector2(x + 5f, y + TilePx - 27f);
                    if (tile == 'M')
                    {
                        requiredCoins.Add(new CoinData { rect = new RectPx(x + 8, y + 5, 18, 20), taken = false });
                        requiredCoinCount += 1;
                    }
                    if (tile == 'D')
                    {
                        door = new RectPx(x, y - 2, 28, 34);
                        doorHitbox = new RectPx(x - 6, y - 10, TilePx + 12, TilePx + 18);
                    }
                    if (tile == 'G') gate = new RectPx(x, y - 2, 28, 34, 'G', tx, ty);
                }
            }

            textZones.Add(new TextZoneDataPx(18, 3, 9, 3, "Ого, последнее испытание, смотри не умри тут XD"));
            textZones.Add(new TextZoneDataPx(12, 7, 12, 11, "Жаркое место!"));
            textZones.Add(new TextZoneDataPx(8, 19, 23, 3, "Чтобы отцепиться от стен, нажмите S"));

            robot = CreateRobot(15, 21, "right", 2.2f, 0.08f, 90);
            fliers.Add(CreateFlier(15, 2, "right", 1.2f, 4, 4));
            fliers.Add(CreateFlier(4, 7, "down", 0.8f, 5, 5));
            fliers.Add(CreateFlier(20, 7, "right", 0.8f, 5, 5));
            fliers.Add(CreateFlier(36, 8, "right", 0.5f, 3, 8));
            fliers.Add(CreateFlier(8, 11, "right", 0.6f, 5, 5));
            fliers.Add(CreateFlier(27, 11, "right", 1f, 5, 5));

            lasers.Add(CreateLaser(2, 7, 5));
            lasers.Add(CreateLaser(18, 8, 7));

            SpawnPlayer();
            SetInitialCamera();
        }

        private void SpawnPlayer()
        {
            player = new PlayerData
            {
                x = spawn.x,
                y = spawn.y,
                w = 22,
                h = 27,
                alive = true,
                facing = 1
            };
        }

        private RobotDataPx CreateRobot(int tx, int ty, string direction, float maxSpeed, float acceleration, int cooldownFrames)
        {
            return new RobotDataPx
            {
                x = tx * TilePx + 2,
                y = ty * TilePx + 3,
                spawnX = tx * TilePx + 2,
                spawnY = ty * TilePx + 3,
                w = TilePx - 4,
                h = TilePx - 5,
                direction = direction == "left" ? -1 : 1,
                initialDirection = direction == "left" ? -1 : 1,
                maxSpeed = maxSpeed,
                acceleration = acceleration,
                cooldownFrames = cooldownFrames,
                state = RobotState.Watching
            };
        }

        private FlierDataPx CreateFlier(int tx, int ty, string direction, float speed, int areaWidthTiles, int areaHeightTiles)
        {
            return new FlierDataPx
            {
                x = tx * TilePx + 2,
                y = ty * TilePx + 2,
                spawnX = tx * TilePx + 2,
                spawnY = ty * TilePx + 2,
                w = TilePx - 4,
                h = TilePx - 4,
                direction = direction,
                initialDirection = direction,
                speed = speed,
                patrol = new RectPx(tx * TilePx, ty * TilePx, areaWidthTiles * TilePx, areaHeightTiles * TilePx)
            };
        }

        private LaserDataPx CreateLaser(int tx, int ty, int radiusTiles)
        {
            var x = tx * TilePx + TilePx / 2f;
            var y = ty * TilePx + TilePx / 2f;
            return new LaserDataPx
            {
                x = x,
                y = y,
                radius = radiusTiles * TilePx,
                chargeMs = 2000,
                fireMs = 230,
                cooldownMs = 850,
                state = LaserState.Idle,
                targetX = x,
                targetY = y,
                beamEndX = x,
                beamEndY = y,
                active = true
            };
        }

        private void Update()
        {
            if (texture == null) return;
            if (paused) return;
            if (!playing)
            {
                var idleKeyboard = Keyboard.current;
                if (idleKeyboard != null && idleKeyboard.rKey.wasPressedThisFrame) ReloadLevel();
                return;
            }
            var now = Time.time * 1000f;
            var dtMs = lastNow <= 0f ? 1000f / 60f : Mathf.Min(50f, Mathf.Max(0f, now - lastNow));
            lastNow = now;

            ReadInput();
            if (freezeFrames > 0)
            {
                freezeFrames -= 1;
                UpdateParticles();
                Render();
                return;
            }

            if (!player.alive)
            {
                respawnTimer -= Time.deltaTime;
                UpdateParticles();
                if (respawnTimer <= 0f) RespawnDynamic();
                Render();
                return;
            }

            UpdateRobot();
            UpdateFliers();
            UpdateLasers(now);
            MovePlayer(dtMs);
            HandlePickupsDoorsText();
            CheckHazards();
            UpdateParticles();
            UpdateCamera();
            UpdateStats();
            Render();
            frame += 1;
            jumpPressed = false;
        }

        private void ReadInput()
        {
            var keyboard = Keyboard.current;
            if (keyboard == null) return;
            if (keyboard.rKey.wasPressedThisFrame) ReloadLevel();
            player.inputLeft = keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed;
            player.inputRight = keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed;
            player.inputDown = keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed;
            player.inputJump = keyboard.spaceKey.isPressed || keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed;
            if (keyboard.spaceKey.wasPressedThisFrame || keyboard.wKey.wasPressedThisFrame || keyboard.upArrowKey.wasPressedThisFrame) jumpPressed = true;
        }

        public void Pause()
        {
            if (texture == null || !playing || player.win || !player.alive) return;
            paused = true;
        }

        public void Resume()
        {
            if (texture == null || player.win) return;
            paused = false;
            lastNow = Time.time * 1000f;
        }

        private void MovePlayer(float dtMs)
        {
            player.prevX = player.x;
            player.prevY = player.y;
            player.touchingWall = 0;
            if (player.wallLatchLockTimer > 0) player.wallLatchLockTimer = Mathf.Max(0, player.wallLatchLockTimer - dtMs);
            if (player.wallJumpLockTimer > 0)
            {
                player.wallJumpLockTimer -= 1;
                if (player.wallJumpLockTimer == 0) player.wallJumpLockSide = 0;
            }

            var horizontalInput = (player.inputRight ? 1 : 0) - (player.inputLeft ? 1 : 0);
            var acceleration = player.grounded ? physics.groundAcceleration : physics.airAcceleration;
            var friction = player.grounded ? physics.groundFriction : physics.airFriction;
            if (horizontalInput != 0 && player.vx * horizontalInput < 0 && physics.turnFriction > 0) player.vx *= physics.turnFriction;
            if (horizontalInput != 0)
            {
                player.vx += horizontalInput * acceleration;
                player.facing = horizontalInput;
            }
            if (horizontalInput == 0) player.vx *= friction;
            player.vx = Mathf.Clamp(player.vx, -physics.maxHorizontalSpeed, physics.maxHorizontalSpeed);

            if (jumpPressed)
            {
                if (player.grounded)
                {
                    StartJump(physics.jumpVelocity);
                    Burst(player.x + player.w * 0.5f, player.y + player.h, Muted, 8);
                }
                else if (player.wallContactSide != 0)
                {
                    StartWallJump();
                    Burst(player.x + (player.wallContactSide > 0 ? player.w : 0), player.y + player.h * 0.55f, Steel, 8);
                }
            }

            player.vy += physics.gravity;
            ApplyJumpHold();
            if (!player.inputJump && player.vy < -1 && physics.jumpReleaseGravity > 0) player.vy += physics.jumpReleaseGravity;

            player.x += player.vx;
            ResolveAxis(true);
            if (player.touchingWall != 0 && player.touchingWall == -player.wallJumpLockSide) player.wallJumpLockSide = 0;
            if (player.touchingWall == 0 && player.wallContactSide != 0 && IsStillTouchingWall(player.wallContactSide)) player.touchingWall = player.wallContactSide;
            ApplyWallSlide();

            if (player.inputDown && !player.grounded && player.vy > -1) player.vy += physics.fastFallGravity;
            player.vy = Mathf.Min(physics.maxFallSpeed, player.vy);

            player.grounded = false;
            player.y += player.vy;
            ResolveAxis(false);

            if (player.grounded)
            {
                player.wallContactSide = 0;
                player.wallContactFrames = 0;
                player.wallJumpLockSide = 0;
                player.wallJumpLockTimer = 0;
                player.wallLatchLockTimer = 0;
                player.wallImpactVx = 0;
                player.jumpHoldFrames = 0;
                player.jumpHoldTotalFrames = 0;
            }
        }

        private void StartJump(float velocity)
        {
            player.vy = velocity;
            player.grounded = false;
            player.jumpHoldFrames = physics.jumpHoldFrames;
            player.jumpHoldTotalFrames = player.jumpHoldFrames;
        }

        private void StartWallJump()
        {
            var jumpSide = player.wallContactSide;
            var outward = -jumpSide;
            var holdingAway = (jumpSide == 1 && player.inputLeft) || (jumpSide == -1 && player.inputRight);
            var holdingToward = (jumpSide == 1 && player.inputRight) || (jumpSide == -1 && player.inputLeft);
            var impactCarry = Mathf.Max(0, player.wallImpactVx * jumpSide) * physics.wallJumpMomentumCarry;

            if (holdingToward && !holdingAway)
            {
                player.vx = outward * physics.wallClimbJumpVelocityX;
                player.vy = physics.wallClimbJumpVelocityY;
            }
            else
            {
                var outwardImpulse = physics.wallJumpVelocityX + impactCarry;
                if (holdingAway) outwardImpulse += physics.wallJumpAwayBoost;
                player.vx = player.vx * physics.wallJumpMomentumCarry + outward * outwardImpulse;
                player.vy = physics.wallJumpVelocityY;
            }

            player.grounded = false;
            player.jumpHoldFrames = Mathf.RoundToInt(physics.jumpHoldFrames * 0.65f);
            player.jumpHoldTotalFrames = player.jumpHoldFrames;
            player.wallJumpLockSide = jumpSide;
            player.wallJumpLockTimer = physics.sameWallRelatchFrames;
            player.wallLatchLockTimer = 0;
            player.wallContactFrames = 0;
            player.wallContactSide = 0;
            player.wallImpactVx = 0;
        }

        private void ApplyJumpHold()
        {
            if (!player.inputJump)
            {
                player.jumpHoldFrames = 0;
                player.jumpHoldTotalFrames = 0;
                return;
            }
            if (player.jumpHoldFrames <= 0 || player.vy >= 0 || physics.jumpHoldForce <= 0) return;
            var totalFrames = Mathf.Max(1, player.jumpHoldTotalFrames);
            var remaining = Mathf.Clamp01(player.jumpHoldFrames / (float)totalFrames);
            var holdForce = physics.jumpHoldForceEnd + (physics.jumpHoldForce - physics.jumpHoldForceEnd) * Mathf.Pow(remaining, physics.jumpHoldDecay);
            player.vy -= holdForce;
            player.jumpHoldFrames -= 1;
        }

        private void ApplyWallSlide()
        {
            var side = player.touchingWall != 0 ? player.touchingWall : (player.wallLatchLockTimer > 0 ? player.wallContactSide : 0);
            var continuingSameLatch = side != 0 && player.wallContactSide == side;
            if (side != 0 && side == player.wallJumpLockSide && !continuingSameLatch)
            {
                player.wallContactSide = 0;
                player.wallContactFrames = 0;
                return;
            }

            if (player.grounded || side == 0 || player.vy < 0)
            {
                if (side == 0 && player.wallLatchLockTimer <= 0)
                {
                    player.wallContactSide = 0;
                    player.wallContactFrames = 0;
                }
                return;
            }

            if (player.inputDown)
            {
                player.wallContactSide = 0;
                player.wallContactFrames = 0;
                player.wallLatchLockTimer = 0;
                return;
            }

            var holdingToward = (side == -1 && player.inputLeft) || (side == 1 && player.inputRight);
            var pressingAway = (side == -1 && player.inputRight) || (side == 1 && player.inputLeft);
            if (!holdingToward && player.wallLatchLockTimer <= 0)
            {
                player.wallContactFrames = 0;
                player.wallContactSide = 0;
                return;
            }
            if (pressingAway && player.wallContactFrames > physics.wallGripFrames && player.wallLatchLockTimer <= 0)
            {
                player.wallContactFrames = 0;
                player.wallContactSide = 0;
                return;
            }

            if (player.wallContactSide != side)
            {
                player.wallContactSide = side;
                player.wallContactFrames = 0;
                player.wallLatchLockTimer = physics.wallLatchControlLockMs;
            }
            player.wallContactFrames += 1;
            var maxSlideSpeed = player.wallContactFrames > physics.wallGripFrames ? physics.wallSlideSpeed : physics.wallGripFallSpeed;
            if (player.vy > maxSlideSpeed)
            {
                player.vy = physics.wallFriction > 0 ? maxSlideSpeed + (player.vy - maxSlideSpeed) * physics.wallFriction : maxSlideSpeed;
            }
        }

        private void ResolveAxis(bool horizontal)
        {
            var bounds = player.Bounds;
            foreach (var tile in SolidRectsNear(bounds))
            {
                if (!bounds.Overlaps(tile)) continue;
                if (horizontal)
                {
                    if (player.vx > 0)
                    {
                        player.x = tile.x - player.w;
                        player.wallImpactVx = player.vx;
                        if (tile.tile != 'U') player.touchingWall = 1;
                    }
                    if (player.vx < 0)
                    {
                        player.x = tile.x + tile.w;
                        player.wallImpactVx = player.vx;
                        if (tile.tile != 'U') player.touchingWall = -1;
                    }
                    player.vx = 0;
                }
                else
                {
                    if (player.vy > 0)
                    {
                        player.y = tile.y - player.h;
                        player.grounded = true;
                    }
                    if (player.vy < 0) player.y = tile.y + tile.h;
                    player.vy = 0;
                }
                bounds = player.Bounds;
            }
        }

        private bool IsStillTouchingWall(int side)
        {
            var probe = new RectPx(player.x + side, player.y + 3, player.w, player.h - 6);
            foreach (var tile in SolidRectsNear(probe))
            {
                if (probe.Overlaps(tile)) return true;
            }
            return false;
        }

        private List<RectPx> SolidRectsNear(RectPx rect)
        {
            var result = new List<RectPx>(16);
            var minTx = Mathf.FloorToInt(rect.x / TilePx) - 1;
            var maxTx = Mathf.FloorToInt((rect.x + rect.w) / TilePx) + 1;
            var minTy = Mathf.FloorToInt(rect.y / TilePx) - 1;
            var maxTy = Mathf.FloorToInt((rect.y + rect.h) / TilePx) + 1;
            for (var ty = minTy; ty <= maxTy; ty++)
            for (var tx = minTx; tx <= maxTx; tx++)
            {
                if (IsSolidTile(tx, ty)) result.Add(new RectPx(tx * TilePx, ty * TilePx, TilePx, TilePx, TileAt(tx, ty), tx, ty));
            }
            if (!gateOpen && rect.Overlaps(gate)) result.Add(gate);
            return result;
        }

        private bool IsSolidTile(int tx, int ty)
        {
            return TileAt(tx, ty) == '#';
        }

        private char TileAt(int tx, int ty)
        {
            if (ty < 0 || ty >= map.Length || tx < 0 || tx >= map[0].Length) return '#';
            return map[ty][tx];
        }

        private void UpdateRobot()
        {
            if (robot.cooldown > 0)
            {
                robot.cooldown -= 1;
                return;
            }
            if (robot.state == RobotState.Watching && RobotCanSeePlayer())
            {
                robot.state = RobotState.Charging;
                Burst(robot.x + robot.w / 2, robot.y + robot.h / 2, Coin, 8);
            }
            if (robot.state != RobotState.Charging) return;

            robot.vx += robot.direction * robot.acceleration;
            robot.vx = Mathf.Clamp(robot.vx, -robot.maxSpeed, robot.maxSpeed);
            robot.x += robot.vx;

            var body = robot.Rect;
            foreach (var tile in ObstacleRectsNear(body))
            {
                if (!body.Overlaps(tile)) continue;
                if (robot.vx > 0) robot.x = tile.x - robot.w;
                if (robot.vx < 0) robot.x = tile.x + tile.w;
                robot.vx = 0;
                robot.direction *= -1;
                robot.state = RobotState.Watching;
                robot.cooldown = robot.cooldownFrames;
                Burst(robot.x + robot.w / 2, robot.y + robot.h / 2, Steel, 12);
                break;
            }
        }

        private bool RobotCanSeePlayer()
        {
            var robotY = robot.y + robot.h / 2;
            var playerY = player.y + player.h / 2;
            if (Mathf.Abs(robotY - playerY) > TilePx * 0.55f) return false;
            var robotX = robot.x + robot.w / 2;
            var playerX = player.x + player.w / 2;
            if (robot.direction > 0 && playerX <= robotX) return false;
            if (robot.direction < 0 && playerX >= robotX) return false;
            return !SegmentBlocked(robotX, robotY, playerX, playerY);
        }

        private void UpdateFliers()
        {
            for (var i = 0; i < fliers.Count; i++)
            {
                var flier = fliers[i];
                flier.direction = ChoosePatrolDirection(flier);
                var vector = DirectionVector(flier.direction);
                flier.x += vector.x * flier.speed;
                flier.y += vector.y * flier.speed;
                flier.ClampToPatrol();
                fliers[i] = flier;
            }
        }

        private string ChoosePatrolDirection(FlierDataPx flier)
        {
            var current = flier.direction ?? "right";
            var probe = NextFlierRect(flier, current);
            if (FlierInsidePatrol(probe, flier) && !ObstacleBlocked(probe)) return current;
            var order = new[] { "right", "down", "left", "up" };
            var index = System.Array.IndexOf(order, current);
            if (index < 0) index = 0;
            for (var i = 1; i <= order.Length; i++)
            {
                var direction = order[(index + i) % order.Length];
                var next = NextFlierRect(flier, direction);
                if (FlierInsidePatrol(next, flier) && !ObstacleBlocked(next)) return direction;
            }
            return OppositeDirection(current);
        }

        private RectPx NextFlierRect(FlierDataPx flier, string direction)
        {
            var vector = DirectionVector(direction);
            var step = Mathf.Max(2f, flier.speed + 1f);
            return new RectPx(flier.x + vector.x * step, flier.y + vector.y * step, flier.w, flier.h);
        }

        private bool FlierInsidePatrol(RectPx rect, FlierDataPx flier)
        {
            return rect.x >= flier.patrol.x && rect.y >= flier.patrol.y && rect.x + rect.w <= flier.patrol.x + flier.patrol.w && rect.y + rect.h <= flier.patrol.y + flier.patrol.h;
        }

        private bool ObstacleBlocked(RectPx rect)
        {
            foreach (var obstacle in ObstacleRectsNear(rect))
                if (rect.Overlaps(obstacle)) return true;
            return false;
        }

        private List<RectPx> ObstacleRectsNear(RectPx rect) => SolidRectsNear(rect);

        private Vector2 DirectionVector(string direction)
        {
            if (direction == "left") return Vector2.left;
            if (direction == "right") return Vector2.right;
            if (direction == "up") return Vector2.up * -1f;
            return Vector2.up;
        }

        private string OppositeDirection(string direction)
        {
            if (direction == "left") return "right";
            if (direction == "right") return "left";
            if (direction == "up") return "down";
            return "up";
        }

        private void UpdateLasers(float now)
        {
            for (var i = 0; i < lasers.Count; i++)
            {
                var laser = lasers[i];
                if (!laser.active)
                {
                    lasers[i] = laser;
                    continue;
                }
                var playerX = player.x + player.w / 2;
                var playerY = player.y + player.h / 2;
                var canSeePlayer = LaserCanSeePlayer(laser, playerX, playerY);
                if (laser.state == LaserState.Idle && canSeePlayer)
                {
                    laser.state = LaserState.Charging;
                    laser.chargeUntil = now + laser.chargeMs;
                    laser.targetX = playerX;
                    laser.targetY = playerY;
                    laser.beamAngle = Mathf.Atan2(laser.targetY - laser.y, laser.targetX - laser.x);
                    ShowMessage("Лазер целится с задержкой. Двигайся.");
                }
                if (laser.state == LaserState.Charging)
                {
                    if (now >= laser.chargeUntil)
                    {
                        laser.state = LaserState.Firing;
                        var end = RaycastSolid(laser.x, laser.y, laser.beamAngle, laser.radius);
                        laser.beamEndX = end.x;
                        laser.beamEndY = end.y;
                        laser.fireUntil = now + laser.fireMs;
                    }
                }
                if (laser.state == LaserState.Firing && now >= laser.fireUntil)
                {
                    laser.state = LaserState.Cooldown;
                    laser.cooldownUntil = now + laser.cooldownMs;
                }
                if (laser.state == LaserState.Cooldown && now >= laser.cooldownUntil) laser.state = LaserState.Idle;
                lasers[i] = laser;
            }
        }

        private bool LaserCanSeePlayer(LaserDataPx laser, float playerX, float playerY)
        {
            if (Vector2.Distance(new Vector2(laser.x, laser.y), new Vector2(playerX, playerY)) > laser.radius) return false;
            return !SegmentBlocked(laser.x, laser.y, playerX, playerY);
        }

        private bool SegmentBlocked(float fromX, float fromY, float toX, float toY)
        {
            var distance = Mathf.Sqrt((toX - fromX) * (toX - fromX) + (toY - fromY) * (toY - fromY));
            var steps = Mathf.Max(1, Mathf.CeilToInt(distance / (TilePx / 3f)));
            for (var i = 1; i < steps; i++)
            {
                var t = i / (float)steps;
                var tx = Mathf.FloorToInt((fromX + (toX - fromX) * t) / TilePx);
                var ty = Mathf.FloorToInt((fromY + (toY - fromY) * t) / TilePx);
                if (IsSolidTile(tx, ty)) return true;
            }
            return false;
        }

        private Vector2 RaycastSolid(float x, float y, float angle, float maxDistance)
        {
            var step = Mathf.Max(4f, TilePx / 4f);
            var dx = Mathf.Cos(angle);
            var dy = Mathf.Sin(angle);
            var last = new Vector2(x, y);
            for (var distance = step; distance <= maxDistance; distance += step)
            {
                var px = x + dx * distance;
                var py = y + dy * distance;
                var tx = Mathf.FloorToInt(px / TilePx);
                var ty = Mathf.FloorToInt(py / TilePx);
                if (IsSolidTile(tx, ty)) return last;
                last = new Vector2(px, py);
            }
            return new Vector2(x + dx * maxDistance, y + dy * maxDistance);
        }

        private void HandlePickupsDoorsText()
        {
            var body = player.Bounds;
            for (var i = 0; i < requiredCoins.Count; i++)
            {
                var coin = requiredCoins[i];
                if (coin.taken || !body.Overlaps(coin.rect)) continue;
                coin.taken = true;
                requiredCoins[i] = coin;
                player.requiredCoins += 1;
                Burst(coin.rect.x + 9, coin.rect.y + 10, Coin, 22);
                if (player.requiredCoins >= RequiredCoinCount())
                {
                    gateOpen = true;
                    ShowMessage($"Все нужные монеты собраны: {player.requiredCoins}/{RequiredCoinCount()}. Проход открылся.");
                }
                else
                {
                    ShowMessage($"Монета засчитана: {player.requiredCoins}/{RequiredCoinCount()}. Остальные выглядят так же.");
                }
            }

            if (body.Overlaps(doorHitbox))
            {
                player.win = true;
                playing = false;
                paused = false;
                Burst(player.x + player.w / 2, player.y + player.h / 2, Coin, 24);
                ShowMessage("Настоящий выход найден. Лабиринт нехотя тебя уважает.");
                Won?.Invoke();
            }

            foreach (var zone in textZones)
            {
                if (body.Overlaps(zone.rect))
                {
                    ShowMessage(zone.text);
                    break;
                }
            }
        }

        private int RequiredCoinCount() => Mathf.Max(1, requiredCoinCount, 3);

        private void CheckHazards()
        {
            var hurtbox = player.Hurtbox;
            var minTx = Mathf.FloorToInt(player.x / TilePx) - 1;
            var maxTx = Mathf.FloorToInt((player.x + player.w) / TilePx) + 1;
            var minTy = Mathf.FloorToInt(player.y / TilePx) - 1;
            var maxTy = Mathf.FloorToInt((player.y + player.h) / TilePx) + 1;
            for (var ty = minTy; ty <= maxTy; ty++)
            for (var tx = minTx; tx <= maxTx; tx++)
            {
                if (TileAt(tx, ty) != 'S') continue;
                var spikeRect = new RectPx(tx * TilePx + 4, ty * TilePx + 8, TilePx - 8, TilePx - 8);
                if (hurtbox.Overlaps(spikeRect)) Die("Шипы снова победили.");
            }
            if (hurtbox.Overlaps(robot.Rect)) Die("Робот увидел прямую линию и выбрал насилие.");
            foreach (var flier in fliers)
                if (hurtbox.Overlaps(flier.Rect)) Die("Летающий робот шел по своему маршруту. Ты тоже.");
            foreach (var laser in lasers)
            {
                if (laser.state != LaserState.Firing) continue;
                var playerX = hurtbox.x + hurtbox.w / 2;
                var playerY = hurtbox.y + hurtbox.h / 2;
                var beamX = laser.beamEndX - laser.x;
                var beamY = laser.beamEndY - laser.y;
                var beamLength = Mathf.Max(1, Mathf.Sqrt(beamX * beamX + beamY * beamY));
                var projection = ((playerX - laser.x) * beamX + (playerY - laser.y) * beamY) / beamLength;
                if (projection < 0 || projection > beamLength) continue;
                var dx = Mathf.Cos(laser.beamAngle);
                var dy = Mathf.Sin(laser.beamAngle);
                var distanceToBeam = Mathf.Abs((playerX - laser.x) * dy - (playerY - laser.y) * dx);
                if (distanceToBeam < 8) Die("Лазер выстрелил туда, где ты был слишком недавно.");
            }
        }

        private void Die(string reason)
        {
            if (!player.alive || player.win) return;
            player.alive = false;
            deaths += 1;
            freezeFrames = DeathFreezeFrames;
            respawnTimer = RespawnSeconds;
            cameraShake = 16;
            Burst(player.x + player.w / 2, player.y + player.h / 2, Spike, 32);
            ShowMessage(reason);
            UpdateStats();
        }

        private void RespawnDynamic()
        {
            foreach (var coin in requiredCoins) { }
            for (var i = 0; i < requiredCoins.Count; i++)
            {
                var coin = requiredCoins[i];
                coin.taken = false;
                requiredCoins[i] = coin;
            }
            gateOpen = false;
            robot.x = robot.spawnX;
            robot.y = robot.spawnY;
            robot.vx = 0;
            robot.direction = robot.initialDirection;
            robot.state = RobotState.Watching;
            robot.cooldown = 0;
            for (var i = 0; i < fliers.Count; i++)
            {
                var flier = fliers[i];
                flier.x = flier.spawnX;
                flier.y = flier.spawnY;
                flier.direction = flier.initialDirection;
                fliers[i] = flier;
            }
            for (var i = 0; i < lasers.Count; i++)
            {
                var laser = lasers[i];
                laser.state = LaserState.Idle;
                laser.targetX = laser.x;
                laser.targetY = laser.y;
                laser.beamEndX = laser.x;
                laser.beamEndY = laser.y;
                lasers[i] = laser;
            }
            cameraShake = 0;
            SpawnPlayer();
            SetInitialCamera();
        }

        public void ReloadLevel()
        {
            deaths = 0;
            cameraShake = 0;
            startedAt = Time.time;
            playing = true;
            paused = false;
            BuildLevel();
            ShowMessage("Эти роботы что-то знают.");
            UpdateStats();
        }

        private void SetInitialCamera()
        {
            cameraX = player.x + player.w / 2 - CanvasWidth / 2f + 30f;
            cameraY = player.y + player.h / 2 - CanvasHeight / 2f + 30f;
            cameraX = Mathf.Clamp(cameraX, 0, Mathf.Max(0, map[0].Length * TilePx - CanvasWidth));
            cameraY = Mathf.Clamp(cameraY, 0, Mathf.Max(0, map.Length * TilePx - CanvasHeight));
        }

        private void UpdateCamera()
        {
            var deadZoneWidth = 250f;
            var deadZoneHeight = 150f;
            var left = (CanvasWidth - deadZoneWidth) / 2;
            var right = left + deadZoneWidth;
            var top = (CanvasHeight - deadZoneHeight) / 2;
            var bottom = top + deadZoneHeight;
            var playerX = player.x + player.w / 2 - cameraX;
            var playerY = player.y + player.h / 2 - cameraY;
            if (playerX < left) cameraX -= left - playerX;
            if (playerX > right) cameraX += playerX - right;
            if (playerY < top) cameraY -= top - playerY;
            if (playerY > bottom) cameraY += playerY - bottom;
            cameraX = Mathf.Clamp(cameraX, 0, Mathf.Max(0, map[0].Length * TilePx - CanvasWidth));
            cameraY = Mathf.Clamp(cameraY, 0, Mathf.Max(0, map.Length * TilePx - CanvasHeight));
        }

        private void Render()
        {
            Clear(Background);
            var pulse = frame;
            var shakeX = 0;
            var shakeY = 0;
            if (cameraShake > 0)
            {
                cameraShake -= 1;
                shakeX = Mathf.RoundToInt(UnityEngine.Random.Range(-4f, 4f));
                shakeY = Mathf.RoundToInt(UnityEngine.Random.Range(-4f, 4f));
            }
            var cameraXi = Mathf.FloorToInt(cameraX) - shakeX;
            var cameraYi = Mathf.FloorToInt(cameraY) - shakeY;
            DrawStaticBackground(cameraXi, cameraYi);
            for (var ty = 0; ty < map.Length; ty++)
            for (var tx = 0; tx < map[ty].Length; tx++)
            {
                var tile = map[ty][tx];
                var x = tx * TilePx - cameraXi;
                var y = ty * TilePx - cameraYi;
                if (tile == '#') DrawWall(x, y);
                if (tile == 'S') DrawSpikes(x, y, pulse);
            }

            DrawRobot(robot, pulse, cameraXi, cameraYi);
            foreach (var flier in fliers) DrawFlier(flier, pulse, cameraXi, cameraYi);
            foreach (var laser in lasers) DrawLaser(laser, pulse, cameraXi, cameraYi);
            foreach (var coin in requiredCoins) DrawCoin(coin, pulse, cameraXi, cameraYi);
            DrawCoinGate(gate, cameraXi, cameraYi);
            DrawDoor(door, PlayerColor, false, cameraXi, cameraYi);
            DrawPlayer(player, pulse, cameraXi, cameraYi);
            DrawParticles(cameraXi, cameraYi);
            DrawScreenOverlay();
            texture.SetPixels32(pixels);
            texture.Apply(false);
        }

        private void DrawStaticBackground(int camX, int camY)
        {
            for (var y = 0; y < map.Length * TilePx; y += 64)
            for (var x = 0; x < map[0].Length * TilePx; x += 64)
            {
                if ((x + y) % 128 == 0) FillRect(x - camX, y - camY, 32, 2, C("172232"));
            }
        }

        private void DrawWall(int x, int y)
        {
            PixelRect(x, y, TilePx, TilePx, Wall, C("0A0D12"));
            FillRect(x + 3, y + 3, TilePx - 6, 5, WallLight);
            FillRect(x + 4, y + TilePx - 8, TilePx - 8, 4, WallDark);
        }

        private void DrawSpikes(int x, int y, int pulse)
        {
            FillRect(x, y + TilePx - 6, TilePx, 6, C("182230"));
            for (var i = 0; i < 3; i++)
            {
                var top = y + 9 + Mathf.Sin(pulse * 0.08f + i) * 2f;
                FillTriangle(x + 5 + i * 9, y + TilePx - 6, x + 10 + i * 9, top, x + 15 + i * 9, y + TilePx - 6, Spike);
            }
        }

        private void DrawCoin(CoinData coin, int pulse, int camX, int camY)
        {
            if (coin.taken) return;
            var bob = Mathf.Sin(pulse * 0.07f) * 2f;
            FillRect(Mathf.RoundToInt(coin.rect.x + 5 - camX), Mathf.RoundToInt(coin.rect.y + 1 + bob - camY), 12, 18, Coin);
            FillRect(Mathf.RoundToInt(coin.rect.x + 8 - camX), Mathf.RoundToInt(coin.rect.y + 5 + bob - camY), 4, 6, C("FFF0A6"));
        }

        private void DrawDoor(RectPx rect, Color32 color, bool locked, int camX, int camY)
        {
            var x = Mathf.RoundToInt(rect.x - camX);
            var y = Mathf.RoundToInt(rect.y - camY);
            PixelRect(x, y, Mathf.RoundToInt(rect.w), Mathf.RoundToInt(rect.h), color, Shadow);
            FillRect(x + 17, y + 17, 5, 5, locked ? Spike : C("071014"));
            BlendRect(x + 5, y + 5, 6, 23, new Color32(255, 255, 255, 31));
        }

        private void DrawCoinGate(RectPx rect, int camX, int camY)
        {
            if (gateOpen)
            {
                StrokeRect(Mathf.RoundToInt(rect.x + 2 - camX), Mathf.RoundToInt(rect.y + 2 - camY), Mathf.RoundToInt(rect.w - 4), Mathf.RoundToInt(rect.h - 4), PlayerColor);
                return;
            }
            var x = Mathf.RoundToInt(rect.x - camX);
            var y = Mathf.RoundToInt(rect.y - camY);
            PixelRect(x, y, Mathf.RoundToInt(rect.w), Mathf.RoundToInt(rect.h), Coin, Shadow);
            FillRect(x + 7, y + 8, 14, 5, C("071014"));
            FillRect(x + 7, y + 16, 14, 5, C("071014"));
            FillRect(x + 7, y + 24, 14, 5, C("071014"));
            FillRect(x + 19, y + 17, 4, 4, C("FFF0A6"));
        }

        private void DrawRobot(RobotDataPx item, int pulse, int camX, int camY)
        {
            var shake = item.state == RobotState.Charging ? Mathf.Sin(pulse * 0.55f) * 1.5f : 0f;
            var x = Mathf.RoundToInt(item.x - camX);
            var y = Mathf.RoundToInt(item.y + shake - camY);
            PixelRect(x, y, Mathf.RoundToInt(item.w), Mathf.RoundToInt(item.h), Steel, C("071014"));
            FillRect(x + (item.direction > 0 ? Mathf.RoundToInt(item.w) - 11 : 7), y + 10, 5, 6, item.state == RobotState.Charging ? Spike : RobotEye);
            FillRect(x + 5, y + Mathf.RoundToInt(item.h) - 7, Mathf.RoundToInt(item.w) - 10, 4, C("172232"));
        }

        private void DrawFlier(FlierDataPx item, int pulse, int camX, int camY)
        {
            var bob = Mathf.Sin(pulse * 0.12f + item.x * 0.02f) * 2f;
            var cx = Mathf.RoundToInt(item.x + item.w / 2 - camX);
            var cy = Mathf.RoundToInt(item.y + item.h / 2 + bob - camY);
            FillCircle(cx + 3, cy + 3, Mathf.RoundToInt(item.w / 2), C("071014"));
            FillCircle(cx, cy, Mathf.RoundToInt(item.w / 2), Flier);
            FillRect(Mathf.RoundToInt(item.x + 9 - camX), Mathf.RoundToInt(item.y + 11 + bob - camY), 4, 5, C("071014"));
            FillRect(Mathf.RoundToInt(item.x + item.w - 13 - camX), Mathf.RoundToInt(item.y + 11 + bob - camY), 4, 5, C("071014"));
        }

        private void DrawLaser(LaserDataPx laser, int pulse, int camX, int camY)
        {
            if (!laser.active) return;
            var x = Mathf.RoundToInt(laser.x - camX);
            var y = Mathf.RoundToInt(laser.y - camY);
            if (laser.state == LaserState.Charging)
            {
                var blink = 0.45f + Mathf.Sin(pulse * 0.35f) * 0.25f;
                var warning = C("FFD15C");
                warning.a = (byte)Mathf.RoundToInt(blink * 255f);
                BlendLine(x, y, Mathf.RoundToInt(laser.targetX - camX), Mathf.RoundToInt(laser.targetY - camY), warning, 2);
                BlendRect(Mathf.RoundToInt(laser.targetX - 4 - camX), Mathf.RoundToInt(laser.targetY - 4 - camY), 8, 8, warning);
            }
            if (laser.state == LaserState.Firing)
            {
                DrawLine(x, y, Mathf.RoundToInt(laser.beamEndX - camX), Mathf.RoundToInt(laser.beamEndY - camY), Spike, 5);
                DrawLine(x, y, Mathf.RoundToInt(laser.beamEndX - camX), Mathf.RoundToInt(laser.beamEndY - camY), C("FFFFFF"), 1);
            }
            var core = laser.state == LaserState.Charging ? Coin : laser.state == LaserState.Firing ? Spike : Key;
            PixelRect(x - 11, y - 11, 22, 22, core, C("071014"));
            FillRect(x - 4, y - 4, 8, 8, C("071014"));
        }

        private void DrawPlayer(PlayerData p, int pulse, int camX, int camY)
        {
            if (!p.alive) return;
            var x = Mathf.FloorToInt(p.x - camX);
            var y = Mathf.FloorToInt(p.y - camY);
            var black = Black;
            var eye = C("F7F2DF");
            var bodyX = x + 1;
            var bodyY = y + 7;
            if (p.facing > 0)
            {
                FillRect(x - 10, y + 16, 5, 5, black);
                FillRect(x - 8, y + 20, 5, 5, black);
                FillRect(x - 4, y + 22, 6, 4, black);
            }
            else
            {
                FillRect(x + Mathf.RoundToInt(p.w) + 5, y + 16, 5, 5, black);
                FillRect(x + Mathf.RoundToInt(p.w) + 3, y + 20, 5, 5, black);
                FillRect(x + Mathf.RoundToInt(p.w) - 1, y + 22, 6, 4, black);
            }
            FillRect(bodyX + 3, bodyY + 4, Mathf.RoundToInt(p.w) - 5, 14, black);
            FillRect(bodyX, bodyY + 8, Mathf.RoundToInt(p.w) + 1, 11, black);
            FillRect(bodyX + 4, bodyY + 18, Mathf.RoundToInt(p.w) - 7, 3, black);
            FillTriangle(bodyX + 2, bodyY + 5, bodyX + 7, bodyY - 5, bodyX + 12, bodyY + 5, black);
            FillTriangle(bodyX + Mathf.RoundToInt(p.w) - 12, bodyY + 5, bodyX + Mathf.RoundToInt(p.w) - 7, bodyY - 5, bodyX + Mathf.RoundToInt(p.w) - 2, bodyY + 5, black);
            FillRect(bodyX + 7, bodyY + 11, 3, 6, eye);
            FillRect(bodyX + Mathf.RoundToInt(p.w) - 10, bodyY + 11, 3, 6, eye);
        }

        private void DrawParticles(int camX, int camY)
        {
            foreach (var particle in particles)
            {
                var alpha = Mathf.Clamp01(particle.life / 44f);
                var color = particle.color;
                color.a = (byte)(255 * alpha);
                BlendRect(Mathf.RoundToInt(particle.x - camX), Mathf.RoundToInt(particle.y - camY), Mathf.RoundToInt(particle.size), Mathf.RoundToInt(particle.size), color);
            }
        }

        private void DrawScreenOverlay()
        {
            for (var y = 0; y < CanvasHeight; y += 4)
            {
                BlendRect(0, y + 2, CanvasWidth, 2, new Color32(0, 0, 0, 20));
                BlendRect(0, y, CanvasWidth, 1, new Color32(255, 255, 255, 8));
            }
        }

        private void Clear(Color32 color)
        {
            for (var i = 0; i < pixels.Length; i++) pixels[i] = color;
        }

        private void PixelRect(int x, int y, int w, int h, Color32 color, Color32 shade)
        {
            FillRect(x + 3, y + 3, w, h, shade);
            FillRect(x, y, w, h, color);
        }

        private void FillRect(int x, int y, int w, int h, Color32 color)
        {
            var x0 = Mathf.Max(0, x);
            var y0 = Mathf.Max(0, y);
            var x1 = Mathf.Min(CanvasWidth, x + w);
            var y1 = Mathf.Min(CanvasHeight, y + h);
            for (var yy = y0; yy < y1; yy++)
            {
                var row = yy * CanvasWidth;
                for (var xx = x0; xx < x1; xx++) pixels[row + xx] = color;
            }
        }

        private void BlendRect(int x, int y, int w, int h, Color32 color)
        {
            var x0 = Mathf.Max(0, x);
            var y0 = Mathf.Max(0, y);
            var x1 = Mathf.Min(CanvasWidth, x + w);
            var y1 = Mathf.Min(CanvasHeight, y + h);
            var a = color.a / 255f;
            for (var yy = y0; yy < y1; yy++)
            {
                var row = yy * CanvasWidth;
                for (var xx = x0; xx < x1; xx++)
                {
                    var dst = pixels[row + xx];
                    pixels[row + xx] = new Color32(
                        (byte)(dst.r + (color.r - dst.r) * a),
                        (byte)(dst.g + (color.g - dst.g) * a),
                        (byte)(dst.b + (color.b - dst.b) * a),
                        255);
                }
            }
        }

        private void StrokeRect(int x, int y, int w, int h, Color32 color)
        {
            FillRect(x, y, w, 2, color);
            FillRect(x, y + h - 2, w, 2, color);
            FillRect(x, y, 2, h, color);
            FillRect(x + w - 2, y, 2, h, color);
        }

        private void FillTriangle(float ax, float ay, float bx, float by, float cx, float cy, Color32 color)
        {
            var minX = Mathf.FloorToInt(Mathf.Min(ax, Mathf.Min(bx, cx)));
            var maxX = Mathf.CeilToInt(Mathf.Max(ax, Mathf.Max(bx, cx)));
            var minY = Mathf.FloorToInt(Mathf.Min(ay, Mathf.Min(by, cy)));
            var maxY = Mathf.CeilToInt(Mathf.Max(ay, Mathf.Max(by, cy)));
            var area = Edge(ax, ay, bx, by, cx, cy);
            if (Mathf.Abs(area) < 0.001f) return;
            for (var y = minY; y <= maxY; y++)
            for (var x = minX; x <= maxX; x++)
            {
                var px = x + 0.5f;
                var py = y + 0.5f;
                var w0 = Edge(bx, by, cx, cy, px, py);
                var w1 = Edge(cx, cy, ax, ay, px, py);
                var w2 = Edge(ax, ay, bx, by, px, py);
                if ((w0 >= 0 && w1 >= 0 && w2 >= 0) || (w0 <= 0 && w1 <= 0 && w2 <= 0)) SetPixel(x, y, color);
            }
        }

        private static float Edge(float ax, float ay, float bx, float by, float px, float py)
        {
            return (px - ax) * (by - ay) - (py - ay) * (bx - ax);
        }

        private void FillCircle(int cx, int cy, int radius, Color32 color)
        {
            var r2 = radius * radius;
            for (var y = cy - radius; y <= cy + radius; y++)
            for (var x = cx - radius; x <= cx + radius; x++)
            {
                var dx = x - cx;
                var dy = y - cy;
                if (dx * dx + dy * dy <= r2) SetPixel(x, y, color);
            }
        }

        private void DrawLine(int x0, int y0, int x1, int y1, Color32 color, int width)
        {
            var dx = Mathf.Abs(x1 - x0);
            var sx = x0 < x1 ? 1 : -1;
            var dy = -Mathf.Abs(y1 - y0);
            var sy = y0 < y1 ? 1 : -1;
            var err = dx + dy;
            while (true)
            {
                FillRect(x0 - width / 2, y0 - width / 2, width, width, color);
                if (x0 == x1 && y0 == y1) break;
                var e2 = 2 * err;
                if (e2 >= dy)
                {
                    err += dy;
                    x0 += sx;
                }
                if (e2 <= dx)
                {
                    err += dx;
                    y0 += sy;
                }
            }
        }

        private void BlendLine(int x0, int y0, int x1, int y1, Color32 color, int width)
        {
            var dx = Mathf.Abs(x1 - x0);
            var sx = x0 < x1 ? 1 : -1;
            var dy = -Mathf.Abs(y1 - y0);
            var sy = y0 < y1 ? 1 : -1;
            var err = dx + dy;
            while (true)
            {
                BlendRect(x0 - width / 2, y0 - width / 2, width, width, color);
                if (x0 == x1 && y0 == y1) break;
                var e2 = 2 * err;
                if (e2 >= dy)
                {
                    err += dy;
                    x0 += sx;
                }
                if (e2 <= dx)
                {
                    err += dx;
                    y0 += sy;
                }
            }
        }

        private void SetPixel(int x, int y, Color32 color)
        {
            if (x < 0 || y < 0 || x >= CanvasWidth || y >= CanvasHeight) return;
            pixels[y * CanvasWidth + x] = color;
        }

        private void Burst(float x, float y, Color32 color, int count)
        {
            for (var i = 0; i < count; i++)
            {
                var angle = Mathf.PI * 2f * i / count + UnityEngine.Random.value * 0.4f;
                var speed = 1.2f + UnityEngine.Random.value * 3.7f;
                particles.Add(new ParticleData
                {
                    x = x,
                    y = y,
                    vx = Mathf.Cos(angle) * speed,
                    vy = Mathf.Sin(angle) * speed,
                    life = 28 + UnityEngine.Random.value * 24,
                    color = color,
                    size = 2 + UnityEngine.Random.value * 5
                });
            }
        }

        private void UpdateParticles()
        {
            for (var i = particles.Count - 1; i >= 0; i--)
            {
                var p = particles[i];
                p.x += p.vx;
                p.y += p.vy;
                p.vy += 0.08f;
                p.life -= 1;
                if (p.life <= 0) particles.RemoveAt(i);
                else particles[i] = p;
            }
        }

        public void ShowMessage(string text)
        {
            if (messageText) messageText.text = text;
        }

        private void UpdateStats()
        {
            if (deathsText) deathsText.text = $"Смерти: {deaths}";
            if (timerText)
            {
                var seconds = Mathf.FloorToInt(Time.time - startedAt);
                timerText.text = $"{seconds / 60:00}:{seconds % 60:00}";
            }
        }

        private static Color32 C(string hex)
        {
            ColorUtility.TryParseHtmlString("#" + hex, out var color);
            return color;
        }

        public IEnumerable<Rect> SolidRectsNear(Rect bounds) { yield break; }
        public void ReloadAfterDeath() => RespawnDynamic();
        public void PlayerDied() => Die("Умер. R - перезапуск.");
        public void BurstWorld(Vector2 worldPosition, Color color, int count) => Burst(worldPosition.x * SourcePixelsPerTile, -worldPosition.y * SourcePixelsPerTile, color, count);
        public void CollectCoin() { }
        public void TryWin()
        {
            player.win = true;
            playing = false;
            paused = false;
            ShowMessage("Уровень пройден. Для рестарта нажми R.");
            Won?.Invoke();
        }
        public Vector2 RaycastSolid(Vector2 origin, Vector2 direction, float maxDistance)
        {
            var end = RaycastSolid(origin.x * SourcePixelsPerTile, -origin.y * SourcePixelsPerTile, Mathf.Atan2(-direction.y, direction.x), maxDistance * SourcePixelsPerTile);
            return new Vector2(end.x / SourcePixelsPerTile, -end.y / SourcePixelsPerTile);
        }
        public static Vector2 SimToWorldCenter(Vector2 topLeft, Vector2 size) => new Vector2(topLeft.x + size.x * 0.5f, -(topLeft.y + size.y * 0.5f));
        public static Vector2 WorldToSimPoint(Vector2 world) => new Vector2(world.x, -world.y);

        private struct RectPx
        {
            public float x, y, w, h;
            public char tile;
            public int tx, ty;

            public RectPx(float x, float y, float w, float h, char tile = '.', int tx = 0, int ty = 0)
            {
                this.x = x;
                this.y = y;
                this.w = w;
                this.h = h;
                this.tile = tile;
                this.tx = tx;
                this.ty = ty;
            }

            public bool Overlaps(RectPx other)
            {
                return x < other.x + other.w && x + w > other.x && y < other.y + other.h && y + h > other.y;
            }
        }

        private struct PlayerData
        {
            public float x, y, w, h, vx, vy, prevX, prevY;
            public bool grounded, alive, win, inputLeft, inputRight, inputDown, inputJump;
            public int facing, touchingWall, wallContactSide, wallContactFrames, wallJumpLockSide, wallJumpLockTimer, jumpHoldFrames, jumpHoldTotalFrames, requiredCoins;
            public float wallLatchLockTimer, wallImpactVx;
            public RectPx Bounds => new RectPx(x, y, w, h);
            public RectPx Hurtbox => new RectPx(x + 3, y + 3, w - 6, h - 5);
        }

        private enum RobotState { Watching, Charging }
        private struct RobotDataPx
        {
            public float x, y, spawnX, spawnY, w, h, vx, maxSpeed, acceleration;
            public int direction, initialDirection, cooldownFrames, cooldown;
            public RobotState state;
            public RectPx Rect => new RectPx(x, y, w, h);
        }

        private struct FlierDataPx
        {
            public float x, y, spawnX, spawnY, w, h, speed;
            public string direction, initialDirection;
            public RectPx patrol;
            public RectPx Rect => new RectPx(x, y, w, h);
            public void ClampToPatrol()
            {
                x = Mathf.Clamp(x, patrol.x, patrol.x + patrol.w - w);
                y = Mathf.Clamp(y, patrol.y, patrol.y + patrol.h - h);
            }
        }

        private enum LaserState { Idle, Charging, Firing, Cooldown }
        private struct LaserDataPx
        {
            public float x, y, radius, chargeMs, fireMs, cooldownMs, chargeUntil, fireUntil, cooldownUntil, targetX, targetY, beamAngle, beamEndX, beamEndY;
            public bool active;
            public LaserState state;
        }

        private struct CoinData
        {
            public RectPx rect;
            public bool taken;
        }

        private struct TextZoneDataPx
        {
            public RectPx rect;
            public string text;
            public TextZoneDataPx(int tx, int ty, int wTiles, int hTiles, string text)
            {
                rect = new RectPx(tx * TilePx, ty * TilePx, wTiles * TilePx, hTiles * TilePx);
                this.text = text;
            }
        }

        private struct ParticleData
        {
            public float x, y, vx, vy, life, size;
            public Color32 color;
        }

        private struct PhysicsProfile
        {
            public float groundAcceleration, airAcceleration, groundFriction, airFriction, turnFriction, maxRunSpeed, maxHorizontalSpeed;
            public float jumpVelocity, jumpHoldForce, jumpHoldForceEnd, jumpHoldDecay, jumpReleaseGravity, gravity, fastFallGravity, maxFallSpeed;
            public float wallJumpVelocityX, wallJumpVelocityY, wallClimbJumpVelocityX, wallClimbJumpVelocityY, wallJumpMomentumCarry, wallJumpAwayBoost;
            public int jumpHoldFrames, wallGripFrames, sameWallRelatchFrames;
            public float wallGripFallSpeed, wallSlideSpeed, wallFriction, wallLatchControlLockMs;

            public static PhysicsProfile LevelThreeMoon()
            {
                var speedFactor = Factor(3, 10, 0.18f, 0.55f, 1.25f);
                var accelerationFactor = Factor(1, 10, 0.42f, 1f, 1.28f);
                var jumpFactor = Factor(10, 10, 0.74f, 0.74f, 1.1f);
                var verticalFactor = Factor(6, 10, 0.58f, 1f, 1.24f);
                var wallJumpFactor = Factor(5, 15, 0.45f, 0.75f, 1f);
                return new PhysicsProfile
                {
                    groundAcceleration = 0.075f * accelerationFactor,
                    airAcceleration = 0.24f * accelerationFactor,
                    groundFriction = 0.965f,
                    airFriction = 0.9994f,
                    turnFriction = 0.995f,
                    maxRunSpeed = 3.35f * speedFactor,
                    maxHorizontalSpeed = 8.2f * speedFactor,
                    jumpVelocity = -4.25f * jumpFactor,
                    jumpHoldFrames = 124,
                    jumpHoldForce = 0.058f * jumpFactor,
                    jumpHoldForceEnd = 0.024f * jumpFactor,
                    jumpHoldDecay = 0.82f,
                    jumpReleaseGravity = 0.018f * verticalFactor,
                    gravity = 0.09f * verticalFactor,
                    fastFallGravity = 0.08f * verticalFactor,
                    maxFallSpeed = 4.8f * verticalFactor,
                    wallJumpVelocityX = 2.85f,
                    wallJumpVelocityY = -5.2f * wallJumpFactor,
                    wallClimbJumpVelocityX = 0.42f,
                    wallClimbJumpVelocityY = -5.65f * wallJumpFactor,
                    wallJumpMomentumCarry = 0.72f,
                    wallJumpAwayBoost = 0.35f,
                    wallGripFrames = 150,
                    wallGripFallSpeed = 0.055f,
                    wallSlideSpeed = 0.6f,
                    wallFriction = 0.5f,
                    sameWallRelatchFrames = 24,
                    wallLatchControlLockMs = 500f
                };
            }

            private static float Factor(int level, int anchor, float min, float anchorFactor, float max)
            {
                if (level <= anchor)
                {
                    var t = (level - 1f) / Mathf.Max(1, anchor - 1);
                    return min + (anchorFactor - min) * t;
                }
                var tt = (level - anchor) / Mathf.Max(1f, 15 - anchor);
                return anchorFactor + (max - anchorFactor) * tt;
            }
        }
    }
}
