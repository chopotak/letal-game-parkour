﻿using UnityEngine;

namespace LethalMaze
{
    public sealed class FlyingRobot : MonoBehaviour
    {
        private Vector2 patrolMin;
        private Vector2 patrolMax;
        private Vector2 direction;
        private float speed;

        public void Init(FlyingRobotData data)
        {
            direction = data.direction.sqrMagnitude > 0f ? data.direction.normalized : Vector2.right;
            speed = data.speed * 60f / LevelRuntime.SourcePixelsPerTile;

            var halfSize = (LevelRuntime.TileSize - 4f / LevelRuntime.SourcePixelsPerTile) * 0.5f;
            patrolMin = new Vector2(data.tx + halfSize, -(data.ty + data.areaHeightTiles) + halfSize);
            patrolMax = new Vector2(data.tx + data.areaWidthTiles - halfSize, -data.ty - halfSize);
        }

        private void Update()
        {
            var next = (Vector2)transform.position + direction * speed * Time.deltaTime;
            if (!InsidePatrol(next) || HitsWall(next))
            {
                direction = NextDirection(direction);
                next = (Vector2)transform.position + direction * speed * Time.deltaTime;
                if (!InsidePatrol(next) || HitsWall(next)) return;
            }
            transform.position = next;
        }

        private bool InsidePatrol(Vector2 position)
        {
            return position.x >= patrolMin.x && position.x <= patrolMax.x && position.y >= patrolMin.y && position.y <= patrolMax.y;
        }

        private static bool HitsWall(Vector2 position)
        {
            foreach (var hit in Physics2D.OverlapBoxAll(position, Vector2.one * (LevelRuntime.TileSize - 4f / LevelRuntime.SourcePixelsPerTile), 0f))
                if (hit.GetComponent<SolidBlock>()) return true;
            return false;
        }

        private static Vector2 NextDirection(Vector2 current)
        {
            if (current == Vector2.right) return Vector2.down;
            if (current == Vector2.down) return Vector2.left;
            if (current == Vector2.left) return Vector2.up;
            return Vector2.right;
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            var player = other.GetComponent<MoonPlayerController>();
            if (player) player.Die();
        }
    }
}

