﻿using UnityEngine;

namespace LethalMaze
{
    public sealed class SolidBlock : MonoBehaviour
    {
    }
}
