using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

namespace LethalMaze
{
    public sealed class GameBootstrap : MonoBehaviour
    {
        private Canvas canvas;
        private GameObject menuOverlay;
        private GameObject pauseOverlay;
        private GameObject winOverlay;
        private GameObject screenFrame;
        private GameObject topbar;
        private GameObject messagePanel;
        private RawImage screenImage;
        private Text messageText;
        private Text deathsText;
        private Text timerText;
        private LevelRuntime runtime;
        private bool started;

        private static readonly Color Background = PixelArt.Hex("111820");
        private static readonly Color Shadow = PixelArt.Hex("020406");
        private static readonly Color Panel = new Color(0.04f, 0.06f, 0.09f, 0.88f);
        private static readonly Color Border = PixelArt.Hex("304057");
        private static readonly Color Gold = PixelArt.Hex("FFD15C");
        private static readonly Color Cyan = PixelArt.Hex("52EADC");
        private static readonly Color Ink = PixelArt.Hex("F7F2DF");
        private static readonly Color Red = PixelArt.Hex("FF4C6A");

        private void Awake()
        {
            EnsureCamera();
            EnsureEventSystem();
            BuildUi();
            runtime = gameObject.AddComponent<LevelRuntime>();
            runtime.Won += ShowWinOverlay;
        }

        private void Update()
        {
            var keyboard = Keyboard.current;
            if (keyboard == null) return;
            if (!started && (keyboard.enterKey.wasPressedThisFrame || keyboard.spaceKey.wasPressedThisFrame)) StartGame();
            if (started && keyboard.escapeKey.wasPressedThisFrame && !winOverlay.activeSelf) TogglePause();
        }

        private void StartGame()
        {
            started = true;
            screenFrame.SetActive(true);
            menuOverlay.SetActive(false);
            pauseOverlay.SetActive(false);
            winOverlay.SetActive(false);
            topbar.SetActive(true);
            messagePanel.SetActive(true);
            runtime.Build(messageText, deathsText, timerText, screenImage);
        }

        private void TogglePause()
        {
            if (pauseOverlay.activeSelf) ResumeGame();
            else PauseGame();
        }

        private void PauseGame()
        {
            runtime.Pause();
            pauseOverlay.SetActive(true);
        }

        private void ResumeGame()
        {
            pauseOverlay.SetActive(false);
            runtime.Resume();
        }

        private void RestartLevel()
        {
            started = true;
            screenFrame.SetActive(true);
            menuOverlay.SetActive(false);
            pauseOverlay.SetActive(false);
            winOverlay.SetActive(false);
            topbar.SetActive(true);
            messagePanel.SetActive(true);
            runtime.ReloadLevel();
            runtime.Resume();
        }

        private void BackToMenu()
        {
            runtime.Pause();
            started = false;
            screenFrame.SetActive(false);
            pauseOverlay.SetActive(false);
            winOverlay.SetActive(false);
            topbar.SetActive(false);
            messagePanel.SetActive(false);
            menuOverlay.SetActive(true);
        }

        private void ShowWinOverlay()
        {
            pauseOverlay.SetActive(false);
            winOverlay.SetActive(true);
        }

        private void BuildUi()
        {
            var canvasObj = new GameObject("UI");
            canvas = canvasObj.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasObj.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(960f, 576f);
            scaler.matchWidthOrHeight = 0.5f;
            canvasObj.AddComponent<GraphicRaycaster>();

            screenFrame = CreatePanel("Screen", canvasObj.transform, new Vector2(0.5f, 0.5f), new Vector2(0f, -4f), new Vector2(960f, 576f), PixelArt.Hex("111820"));
            AddOutline(screenFrame, Border, Shadow);
            var rawObj = new GameObject("Game Canvas");
            rawObj.transform.SetParent(screenFrame.transform, false);
            var rawRect = rawObj.AddComponent<RectTransform>();
            rawRect.anchorMin = rawRect.anchorMax = new Vector2(0.5f, 0.5f);
            rawRect.anchoredPosition = Vector2.zero;
            rawRect.sizeDelta = new Vector2(960f, 576f);
            screenImage = rawObj.AddComponent<RawImage>();
            screenImage.color = Color.white;

            topbar = CreatePanel("Topbar", canvasObj.transform, new Vector2(0.5f, 1f), new Vector2(0f, -42f), new Vector2(960f, 84f), new Color(0f, 0f, 0f, 0f));
            var kicker = CreateText("Kicker", topbar.transform, new Vector2(0f, 1f), new Vector2(0f, 0f), new Vector2(1f, 1f), 1, TextAnchor.MiddleLeft, Cyan);
            kicker.text = string.Empty;
            var levelPanel = CreatePanel("Level Panel", topbar.transform, new Vector2(0f, 1f), new Vector2(120f, -48f), new Vector2(218f, 34f), Panel);
            AddOutline(levelPanel, Border, Shadow);
            var title = CreateText("Title", levelPanel.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(206f, 28f), 14, TextAnchor.MiddleCenter, Ink);
            title.text = "Лабиринт с роботами";
            CreateButton("Pause Button", topbar.transform, new Vector2(1f, 1f), new Vector2(-390f, -48f), new Vector2(170f, 34f), Panel, "Пауза  Esc", 14, PauseGame);
            deathsText = StatText("Deaths", topbar.transform, new Vector2(1f, 1f), new Vector2(-228f, -48f), "Смерти: 0");
            timerText = StatText("Timer", topbar.transform, new Vector2(1f, 1f), new Vector2(-104f, -48f), "00:00");
            topbar.SetActive(false);

            messagePanel = CreatePanel("Message Panel", canvasObj.transform, new Vector2(0.5f, 0f), new Vector2(0f, 34f), new Vector2(900f, 45f), Panel);
            AddOutline(messagePanel, Border, Shadow);
            messageText = CreateText("Message", messagePanel.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(860f, 34f), 16, TextAnchor.MiddleLeft, Ink);
            messagePanel.SetActive(false);

            screenFrame.SetActive(false);

            menuOverlay = CreatePanel("Menu Overlay", canvasObj.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(960f, 576f), Background);
            BuildMenu(menuOverlay.transform);
            pauseOverlay = CreatePanel("Pause Overlay", canvasObj.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(960f, 576f), new Color(0.02f, 0.03f, 0.05f, 0.72f));
            BuildPauseOverlay(pauseOverlay.transform);
            pauseOverlay.SetActive(false);
            winOverlay = CreatePanel("Win Overlay", canvasObj.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(960f, 576f), new Color(0.02f, 0.03f, 0.05f, 0.76f));
            BuildWinOverlay(winOverlay.transform);
            winOverlay.SetActive(false);
        }

        private void BuildMenu(Transform root)
        {
            var window = CreatePanel("Menu Window", root, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(760f, 470f), new Color(0.05f, 0.07f, 0.10f, 0.98f));
            AddOutline(window, Border, Shadow);
            CreateAccent(window.transform, new Vector2(0.5f, 0.5f), new Vector2(-205f, 142f), new Vector2(190f, 6f), Cyan);
            CreateAccent(window.transform, new Vector2(0.5f, 0.5f), new Vector2(205f, -142f), new Vector2(190f, 6f), Red);
            CreateAccent(window.transform, new Vector2(0.5f, 0.5f), new Vector2(0f, -176f), new Vector2(560f, 2f), Border);

            var kicker = CreateText("Menu Kicker", root, new Vector2(0.5f, 0.5f), new Vector2(0f, 126f), new Vector2(620f, 26f), 14, TextAnchor.MiddleCenter, Cyan);
            kicker.text = "ретро-игра";
            var title = CreateText("Menu Title", root, new Vector2(0.5f, 0.5f), new Vector2(0f, 78f), new Vector2(680f, 58f), 40, TextAnchor.MiddleCenter, Ink);
            title.text = "Смертельный лабиринт";
            var tagline = CreateText("Menu Tagline", root, new Vector2(0.5f, 0.5f), new Vector2(0f, 28f), new Vector2(560f, 34f), 14, TextAnchor.MiddleCenter, PixelArt.Hex("B8C6D6"));
            tagline.text = "Роботы, монетки и физика.";

            var playObj = CreatePanel("Play Tile", root, new Vector2(0.5f, 0.5f), new Vector2(0f, -76f), new Vector2(360f, 74f), Gold);
            AddOutline(playObj, Gold, Shadow);
            var button = playObj.AddComponent<Button>();
            button.targetGraphic = playObj.GetComponent<Image>();
            button.onClick.AddListener(StartGame);
            var playSmall = CreateText("Play Small", playObj.transform, new Vector2(0.5f, 0.5f), new Vector2(0f, 0f), new Vector2(1f, 1f), 1, TextAnchor.MiddleCenter, PixelArt.Hex("071014"));
            playSmall.text = string.Empty;
            var playText = CreateText("Play Label", playObj.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(330f, 50f), 28, TextAnchor.MiddleCenter, PixelArt.Hex("071014"));
            playText.text = "Играть";

            var version = CreateText("Version", root, new Vector2(0.5f, 0.5f), new Vector2(0f, -204f), new Vector2(420f, 24f), 11, TextAnchor.MiddleCenter, PixelArt.Hex("7B8EA7"));
            version.text = "v.1.2.3";
        }

        private void BuildPauseOverlay(Transform root)
        {
            var window = CreatePanel("Pause Window", root, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(640f, 430f), new Color(0.05f, 0.07f, 0.10f, 0.97f));
            AddOutline(window, Border, Shadow);
            var kicker = CreateText("Pause Kicker", window.transform, new Vector2(0.5f, 0.5f), new Vector2(0f, 166f), new Vector2(460f, 24f), 14, TextAnchor.MiddleCenter, Cyan);
            kicker.text = "пауза";
            var title = CreateText("Pause Title", window.transform, new Vector2(0.5f, 0.5f), new Vector2(0f, 126f), new Vector2(460f, 48f), 34, TextAnchor.MiddleCenter, Ink);
            title.text = "Легенда";

            AddLegendRow(window.transform, -102f, "W / Space", "прыжок");
            AddLegendRow(window.transform, -62f, "A / D", "движение");
            AddLegendRow(window.transform, -22f, "S", "быстрый спуск");
            AddLegendRow(window.transform, 18f, "R", "рестарт");
            AddLegendRow(window.transform, 58f, "Esc", "пауза");

            CreateButton("Resume", window.transform, new Vector2(0.5f, 0.5f), new Vector2(-180f, -154f), new Vector2(150f, 48f), Gold, "Продолжить", 16, ResumeGame);
            CreateButton("Restart Pause", window.transform, new Vector2(0.5f, 0.5f), new Vector2(0f, -154f), new Vector2(150f, 48f), Panel, "Заново", 16, RestartLevel);
            CreateButton("Menu Pause", window.transform, new Vector2(0.5f, 0.5f), new Vector2(180f, -154f), new Vector2(150f, 48f), Panel, "В меню", 16, BackToMenu);
        }

        private void BuildWinOverlay(Transform root)
        {
            var window = CreatePanel("Win Window", root, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(500f, 310f), new Color(0.05f, 0.07f, 0.10f, 0.97f));
            AddOutline(window, Border, Shadow);
            CreateAccent(window.transform, new Vector2(0.5f, 0.5f), new Vector2(-160f, 104f), new Vector2(130f, 6f), Cyan);
            CreateAccent(window.transform, new Vector2(0.5f, 0.5f), new Vector2(160f, -104f), new Vector2(130f, 6f), Red);
            var kicker = CreateText("Win Kicker", window.transform, new Vector2(0.5f, 0.5f), new Vector2(0f, 94f), new Vector2(420f, 24f), 14, TextAnchor.MiddleCenter, Cyan);
            kicker.text = "победа";
            var title = CreateText("Win Title", window.transform, new Vector2(0.5f, 0.5f), new Vector2(0f, 48f), new Vector2(420f, 52f), 34, TextAnchor.MiddleCenter, Ink);
            title.text = "Уровень пройден";
            var hint = CreateText("Win Hint", window.transform, new Vector2(0.5f, 0.5f), new Vector2(0f, 4f), new Vector2(390f, 28f), 14, TextAnchor.MiddleCenter, PixelArt.Hex("B8C6D6"));
            hint.text = "Можно пройти еще раз или выйти в меню.";
            CreateButton("Win Restart", window.transform, new Vector2(0.5f, 0.5f), new Vector2(-98f, -74f), new Vector2(180f, 54f), Gold, "Играть заново", 16, RestartLevel);
            CreateButton("Win Menu", window.transform, new Vector2(0.5f, 0.5f), new Vector2(112f, -74f), new Vector2(160f, 54f), Panel, "В меню", 16, BackToMenu);
        }

        private void AddLegendRow(Transform parent, float y, string key, string text)
        {
            var keyPanel = CreatePanel("Legend Key", parent, new Vector2(0.5f, 0.5f), new Vector2(-150f, y), new Vector2(100f, 28f), Panel);
            AddOutline(keyPanel, Border, Shadow);
            var keyText = CreateText("Legend Key Text", keyPanel.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(92f, 22f), 13, TextAnchor.MiddleCenter, Gold);
            keyText.text = key;
            var label = CreateText("Legend Label", parent, new Vector2(0.5f, 0.5f), new Vector2(35f, y), new Vector2(250f, 28f), 14, TextAnchor.MiddleLeft, Ink);
            label.text = text;
        }

        private GameObject CreateButton(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size, Color color, string label, int fontSize, Action onClick)
        {
            var obj = CreatePanel(name, parent, anchor, pos, size, color);
            AddOutline(obj, color == Gold ? Gold : Border, Shadow);
            var button = obj.AddComponent<Button>();
            button.targetGraphic = obj.GetComponent<Image>();
            button.onClick.AddListener(() => onClick());
            var text = CreateText($"{name} Label", obj.transform, new Vector2(0.5f, 0.5f), Vector2.zero, size - new Vector2(14f, 10f), fontSize, TextAnchor.MiddleCenter, color == Gold ? PixelArt.Hex("071014") : Ink);
            text.text = label;
            return obj;
        }

        private Text StatText(string name, Transform parent, Vector2 anchor, Vector2 pos, string value)
        {
            var panel = CreatePanel($"{name} Panel", parent, anchor, pos, new Vector2(112f, 34f), Panel);
            AddOutline(panel, Border, Shadow);
            var text = CreateText(name, panel.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(104f, 28f), 14, TextAnchor.MiddleCenter, Ink);
            text.text = value;
            return text;
        }

        private static GameObject CreatePanel(string name, Transform parent, Vector2 anchor, Vector2 anchoredPos, Vector2 size, Color color)
        {
            var obj = new GameObject(name);
            obj.transform.SetParent(parent, false);
            var rect = obj.AddComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = anchor;
            rect.anchoredPosition = anchoredPos;
            rect.sizeDelta = size;
            var image = obj.AddComponent<Image>();
            image.color = color;
            return obj;
        }

        private static void AddOutline(GameObject obj, Color border, Color shadow)
        {
            var outline = obj.AddComponent<Outline>();
            outline.effectColor = border;
            outline.effectDistance = new Vector2(2f, -2f);
            var shadowFx = obj.AddComponent<Shadow>();
            shadowFx.effectColor = shadow;
            shadowFx.effectDistance = new Vector2(4f, -4f);
        }

        private static void CreateAccent(Transform parent, Vector2 anchor, Vector2 pos, Vector2 size, Color color)
        {
            CreatePanel("Accent", parent, anchor, pos, size, color);
        }

        private Text CreateText(string name, Transform parent, Vector2 anchor, Vector2 anchoredPos, Vector2 size, int fontSize, TextAnchor align, Color color)
        {
            var obj = new GameObject(name);
            obj.transform.SetParent(parent, false);
            var rect = obj.AddComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = anchor;
            rect.anchoredPosition = anchoredPos;
            rect.sizeDelta = size;
            var text = obj.AddComponent<Text>();
            text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.fontSize = fontSize;
            text.fontStyle = FontStyle.Bold;
            text.alignment = align;
            text.color = color;
            return text;
        }

        private void EnsureEventSystem()
        {
            if (FindAnyObjectByType<EventSystem>()) return;
            var eventSystem = new GameObject("EventSystem");
            eventSystem.AddComponent<EventSystem>();
            eventSystem.AddComponent<InputSystemUIInputModule>();
        }

        private void EnsureCamera()
        {
            if (!Camera.main)
            {
                var cameraObj = new GameObject("Main Camera");
                cameraObj.tag = "MainCamera";
                cameraObj.AddComponent<Camera>();
            }

            var camera = Camera.main;
            camera.orthographic = true;
            camera.orthographicSize = 6f;
            camera.backgroundColor = Background;
            camera.allowHDR = false;
            camera.allowMSAA = false;
            if (!camera.GetComponent<FixedAspectCamera>()) camera.gameObject.AddComponent<FixedAspectCamera>();
            if (!camera.GetComponent<FollowCamera>()) camera.gameObject.AddComponent<FollowCamera>();
        }
    }
}
