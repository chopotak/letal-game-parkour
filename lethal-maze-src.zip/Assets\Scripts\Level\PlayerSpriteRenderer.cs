using UnityEngine;

namespace LethalMaze
{
    [RequireComponent(typeof(SpriteRenderer))]
    public class PlayerSpriteRenderer : MonoBehaviour
    {
        // enlarge canvas to include tail pixels (left/right)
        public int pixelWidth = 48;
        public int pixelHeight = 32;
        public float pixelsPerUnit = 48f;
            public float sizeMultiplier = 1.0f;

        public int Facing { get; set; } = 1; // 1 = right, -1 = left
        public bool Grounded { get; set; } = true;
        public bool Alive { get; set; } = true;

        private Texture2D tex;
        private SpriteRenderer sr;
        private float baseScaleX = 1f;
        private float baseScaleY = 1f;

        private readonly Color32 colorBody = Hex("71F79F");
        private readonly Color32 colorEye = Hex("F7F2DF");
        private readonly Color32 colorBlack = Hex("020406");

        // helper to draw triangle (filled) using simple scanline fill
        private void FillTriangle(Color32[] pixels, int w, int h, int x1, int y1, int x2, int y2, int x3, int y3, Color32 col)
        {
            // bounding box
            int minX = Mathf.Clamp(Mathf.Min(x1, Mathf.Min(x2, x3)), 0, w - 1);
            int maxX = Mathf.Clamp(Mathf.Max(x1, Mathf.Max(x2, x3)), 0, w - 1);
            int minY = Mathf.Clamp(Mathf.Min(y1, Mathf.Min(y2, y3)), 0, h - 1);
            int maxY = Mathf.Clamp(Mathf.Max(y1, Mathf.Max(y2, y3)), 0, h - 1);
            for (int yy = minY; yy <= maxY; yy++)
            {
                for (int xx = minX; xx <= maxX; xx++)
                {
                    // barycentric technique
                    float denom = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3);
                    if (Mathf.Abs(denom) < 1e-6f) continue;
                    float a = ((y2 - y3) * (xx - x3) + (x3 - x2) * (yy - y3)) / denom;
                    float b = ((y3 - y1) * (xx - x3) + (x1 - x3) * (yy - y3)) / denom;
                    float c = 1f - a - b;
                    if (a >= 0 && b >= 0 && c >= 0)
                    {
                        SetPixel(pixels, w, h, xx, yy, col);
                    }
                }
            }
        }

        private static Color32 Hex(string h)
        {
            if (string.IsNullOrEmpty(h)) return new Color32(0, 0, 0, 255);
            if (h.StartsWith("#")) h = h.Substring(1);
            byte r = byte.Parse(h.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
            byte g = byte.Parse(h.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
            byte b = byte.Parse(h.Substring(4, 2), System.Globalization.NumberStyles.HexNumber);
            return new Color32(r, g, b, 255);
        }

        void Awake()
        {
            sr = GetComponent<SpriteRenderer>();
            tex = new Texture2D(pixelWidth, pixelHeight, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;
            var sprite = Sprite.Create(tex, new Rect(0, 0, pixelWidth, pixelHeight), new Vector2(0.5f, 0.5f), pixelsPerUnit);
            sr.sprite = sprite;
            sr.color = Color.white;
            sr.drawMode = SpriteDrawMode.Simple;
            // ensure this sprite renders above PixelArt children/other sprites
            sr.sortingOrder = 100;
            sr.sortingLayerName = "Default";
            transform.localPosition = Vector3.zero;

            // scale sprite so its world width equals LevelRuntime.PlayerWidth
            var desiredWorldWidth = LevelRuntime.PlayerWidth;
            var actualSpriteWorldWidth = (float)pixelWidth / Mathf.Max(1f, pixelsPerUnit);
            var uniformScale = actualSpriteWorldWidth > 0f ? desiredWorldWidth / actualSpriteWorldWidth : 1f;
            uniformScale *= Mathf.Max(0.01f, sizeMultiplier);
            baseScaleX = uniformScale;
            baseScaleY = uniformScale;
            transform.localScale = new Vector3(baseScaleX, baseScaleY, 1f);
        }

        void Update()
        {
            if (!Alive) { sr.enabled = false; return; }
            sr.enabled = true;
            DrawPlayer(Mathf.PI * 2f * Time.time * 0.0625f);
            // use SpriteRenderer.flipX instead of negating transform.scale
            sr.flipX = Facing < 0;
        }

        private void DrawPlayer(float pulse)
        {
            // clear
            var clearCol = new Color32(0, 0, 0, 0);
            var pixels = tex.GetPixels32();
            for (int i = 0; i < pixels.Length; i++) pixels[i] = clearCol;

            // follow JS spritePainter.player exactly
            int playerW = 22;
            int marginLeft = 10; // so tail pixels fit
            int marginTop = 0;
            int x = marginLeft + 1; // corresponds to bodyX in JS
            int y = marginTop + 7;  // corresponds to bodyY in JS

            int tailBob = Mathf.RoundToInt(Mathf.Sin(pulse * 0.14f));

            // fillStyle = black (no-op placeholder removed)

            if (Facing > 0)
            {
                SetPixelBlock(pixels, pixelWidth, pixelHeight, (x - 11), y + 16 + tailBob, 5, 5, colorBlack); // x-10 in JS -> bodyX-11 here
                SetPixelBlock(pixels, pixelWidth, pixelHeight, (x - 9), y + 20 + tailBob, 5, 5, colorBlack);  // x-8 -> bodyX-9
                SetPixelBlock(pixels, pixelWidth, pixelHeight, (x - 5), y + 22 + tailBob, 6, 4, colorBlack);  // x-4 -> bodyX-5
            }
            else
            {
                SetPixelBlock(pixels, pixelWidth, pixelHeight, (x + playerW + 4), y + 16 + tailBob, 5, 5, colorBlack); // x+player.w+5 -> bodyX+playerW+4
                SetPixelBlock(pixels, pixelWidth, pixelHeight, (x + playerW + 2), y + 20 + tailBob, 5, 5, colorBlack);
                SetPixelBlock(pixels, pixelWidth, pixelHeight, (x + playerW + 0), y + 22 + tailBob, 6, 4, colorBlack);
            }

            FillRect(pixels, pixelWidth, pixelHeight, x + 3, y + 4, playerW - 5, 14, colorBlack);
            FillRect(pixels, pixelWidth, pixelHeight, x + 0, y + 8, playerW + 1, 11, colorBlack);
            FillRect(pixels, pixelWidth, pixelHeight, x + 4, y + 18, playerW - 7, 3, colorBlack);

            // left triangle: (bodyX + 2, bodyY + 5), (bodyX + 7, bodyY - 5), (bodyX + 12, bodyY + 5)
            FillTriangle(pixels, pixelWidth, pixelHeight, x + 2, y + 5, x + 7, y - 5, x + 12, y + 5, colorBlack);
            // right triangle
            FillTriangle(pixels, pixelWidth, pixelHeight, x + playerW - 12, y + 5, x + playerW - 7, y - 5, x + playerW - 2, y + 5, colorBlack);

            // eyes
            FillRect(pixels, pixelWidth, pixelHeight, x + 7, y + 11, 3, 6, colorEye);
            FillRect(pixels, pixelWidth, pixelHeight, x + playerW - 10, y + 11, 3, 6, colorEye);

            tex.SetPixels32(pixels);
            tex.Apply(false);
        }

        private void FillRect(Color32[] pixels, int w, int h, int rx, int ry, int rw, int rh, Color32 col)
        {
            for (int yy = 0; yy < rh; yy++)
                for (int xx = 0; xx < rw; xx++)
                    SetPixel(pixels, w, h, rx + xx, ry + yy, col);
        }

        private void SetPixelBlock(Color32[] pixels, int w, int h, int rx, int ry, int rw, int rh, Color32 col)
        {
            FillRect(pixels, w, h, rx, ry, rw, rh, col);
        }

        private void SetPixel(Color32[] pixels, int w, int h, int px, int py, Color32 col)
        {
            if (px < 0 || py < 0 || px >= w || py >= h) return;
            // texture y=0 is bottom; our JS painter uses top-left origin — flip y
            int fy = (h - 1) - py;
            pixels[fy * w + px] = col;
        }
    }
}
