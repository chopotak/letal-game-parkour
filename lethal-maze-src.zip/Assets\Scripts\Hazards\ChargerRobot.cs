﻿using UnityEngine;

namespace LethalMaze
{
    public sealed class ChargerRobot : MonoBehaviour
    {
        private LevelRuntime level;
        private Rigidbody2D body;
        private int direction;
        private float maxSpeed;
        private float acceleration;
        private float cooldown;
        private float cooldownLeft;
        private bool charging;

        public void Init(LevelRuntime runtime, RobotData data)
        {
            level = runtime;
            direction = data.direction >= 0 ? 1 : -1;
            maxSpeed = data.maxSpeed * 60f / LevelRuntime.SourcePixelsPerTile;
            acceleration = data.acceleration * 3600f / LevelRuntime.SourcePixelsPerTile;
            cooldown = data.cooldownSeconds;
        }

        private void Awake()
        {
            body = gameObject.AddComponent<Rigidbody2D>();
            body.gravityScale = 0f;
            body.freezeRotation = true;
            var col = gameObject.AddComponent<BoxCollider2D>();
            col.size = new Vector2(0.8f, 0.8f);
        }

        private void FixedUpdate()
        {
            if (cooldownLeft > 0f)
            {
                cooldownLeft -= Time.fixedDeltaTime;
                body.linearVelocity = Vector2.zero;
                return;
            }

            if (!charging && CanSeePlayer()) charging = true;
            if (!charging) return;

            var vx = Mathf.MoveTowards(body.linearVelocity.x, direction * maxSpeed, acceleration * Time.fixedDeltaTime);
            body.linearVelocity = new Vector2(vx, 0f);
        }

        private bool CanSeePlayer()
        {
            var player = level.PlayerTransform;
            if (!player) return false;
            if (Mathf.Abs(player.position.y - transform.position.y) > 0.55f) return false;
            if (direction > 0 && player.position.x <= transform.position.x) return false;
            if (direction < 0 && player.position.x >= transform.position.x) return false;
            foreach (var hit in Physics2D.LinecastAll(transform.position, player.position))
            {
                if (hit.collider.transform == transform) continue;
                if (hit.collider.GetComponent<MoonPlayerController>()) return true;
                if (hit.collider.GetComponent<SolidBlock>()) return false;
            }
            return false;
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            if (collision.collider.GetComponent<MoonPlayerController>())
            {
                collision.collider.GetComponent<MoonPlayerController>().Die();
                return;
            }
            if (!collision.collider.GetComponent<SolidBlock>()) return;
            direction *= -1;
            charging = false;
            cooldownLeft = cooldown;
            body.linearVelocity = Vector2.zero;
        }
    }
}

