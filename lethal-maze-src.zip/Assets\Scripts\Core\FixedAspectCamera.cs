using UnityEngine;

namespace LethalMaze
{
    [ExecuteAlways]
    public sealed class FixedAspectCamera : MonoBehaviour
    {
        public float TargetAspect = 5f / 3f;

        private void LateUpdate()
        {
            if (Screen.height <= 0 || TargetAspect <= 0f) return;
            var windowAspect = Screen.width / (float)Screen.height;
            var camera = GetComponent<Camera>();
            if (!camera) return;

            if (windowAspect > TargetAspect)
            {
                var width = TargetAspect / windowAspect;
                camera.rect = new Rect((1f - width) * 0.5f, 0f, width, 1f);
            }
            else
            {
                var height = windowAspect / TargetAspect;
                camera.rect = new Rect(0f, (1f - height) * 0.5f, 1f, height);
            }
        }
    }
}
