﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace LethalMaze
{
    public enum TileKind { Empty, Wall, Spike, Coin, Gate, Door, Player }

    [Serializable]
    public sealed class TextZoneData
    {
        public int tx;
        public int ty;
        public int wTiles;
        public int hTiles;
        public string text;
    }

    [Serializable]
    public sealed class RobotData
    {
        public int tx;
        public int ty;
        public int direction;
        public float maxSpeed;
        public float acceleration;
        public float cooldownSeconds;
    }

    [Serializable]
    public sealed class FlyingRobotData
    {
        public int tx;
        public int ty;
        public Vector2 direction;
        public float speed;
        public int areaWidthTiles;
        public int areaHeightTiles;
    }

    [Serializable]
    public sealed class LaserData
    {
        public int tx;
        public int ty;
        public int radiusTiles;
        public float chargeSeconds;
        public float fireSeconds;
        public float cooldownSeconds;
    }

    public sealed class MazeLevelData
    {
        public const float TileSize = 1f;
        public readonly string Name = "Лабиринт с роботами";
        public readonly string[] Map =
        {
            "########################################",
            "###########################.....########",
            "###############....########.....########",
            "#########....#..##..............########",
            "#########....#..##.....................#",
            "#########.D..G.........................#",
            "###########################............#",
            "#........###.....###.....##.....####...#",
            "#....###.###.###.....###.##.###.####...#",
            "#....###.###.###.....###.##.###.####.#.#",
            "#.M..###.###.###.....###.##.###.####.#.#",
            "#........................##.....####.#.#",
            "########.###.###.###.###.##.###.####.#.#",
            "########.###.###.###.###.##.###.####...#",
            "########.###.###.###.###.##.###...##.M.#",
            "########..........................##...#",
            "########.###.#####.....#################",
            "########.###.#####S.M.S#################",
            "########.###.###########################",
            "########......................##########",
            "########...................P..##########",
            "###############.........################",
            "########################################",
            "########################################",
            "########################################"
        };

        public readonly TextZoneData[] TextZones =
        {
            new TextZoneData { tx = 18, ty = 3, wTiles = 9, hTiles = 3, text = "Ого, последнее испытание, смотри не умри тут XD" },
            new TextZoneData { tx = 12, ty = 7, wTiles = 12, hTiles = 11, text = "Жаркое место!" },
            new TextZoneData { tx = 8, ty = 19, wTiles = 23, hTiles = 3, text = "Чтобы отцепиться от стен, нажмите S" }
        };

        public readonly RobotData[] Robots =
        {
            new RobotData { tx = 15, ty = 21, direction = 1, maxSpeed = 2.2f, acceleration = 0.08f, cooldownSeconds = 1.5f }
        };

        public readonly FlyingRobotData[] Fliers =
        {
            new FlyingRobotData { tx = 15, ty = 2, direction = Vector2.right, speed = 1.2f, areaWidthTiles = 4, areaHeightTiles = 4 },
            new FlyingRobotData { tx = 4, ty = 7, direction = Vector2.down, speed = 0.8f, areaWidthTiles = 5, areaHeightTiles = 5 },
            new FlyingRobotData { tx = 20, ty = 7, direction = Vector2.right, speed = 0.8f, areaWidthTiles = 5, areaHeightTiles = 5 },
            new FlyingRobotData { tx = 36, ty = 8, direction = Vector2.right, speed = 0.5f, areaWidthTiles = 3, areaHeightTiles = 8 },
            new FlyingRobotData { tx = 8, ty = 11, direction = Vector2.right, speed = 0.6f, areaWidthTiles = 5, areaHeightTiles = 5 },
            new FlyingRobotData { tx = 27, ty = 11, direction = Vector2.right, speed = 1f, areaWidthTiles = 5, areaHeightTiles = 5 }
        };

        public readonly LaserData[] Lasers =
        {
            new LaserData { tx = 2, ty = 7, radiusTiles = 5, chargeSeconds = 2f, fireSeconds = 0.23f, cooldownSeconds = 0.85f },
            new LaserData { tx = 18, ty = 8, radiusTiles = 7, chargeSeconds = 2f, fireSeconds = 0.23f, cooldownSeconds = 0.85f }
        };
    }
}
