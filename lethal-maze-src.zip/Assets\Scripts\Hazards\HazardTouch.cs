﻿using UnityEngine;

namespace LethalMaze
{
    public sealed class HazardTouch : MonoBehaviour
    {
        private void OnTriggerEnter2D(Collider2D other)
        {
            KillPlayer(other);
        }

        private void OnTriggerStay2D(Collider2D other)
        {
            KillPlayer(other);
        }

        private static void KillPlayer(Collider2D other)
        {
            var player = other.GetComponent<MoonPlayerController>();
            if (player != null) player.Die();
        }
    }
}
