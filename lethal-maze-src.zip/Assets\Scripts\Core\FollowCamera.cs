﻿using UnityEngine;

namespace LethalMaze
{
    public sealed class FollowCamera : MonoBehaviour
    {
        public Transform Target;
        public Vector2 DeadZone = new Vector2(3.90625f, 2.34375f);
        public Vector2 LevelSize = new Vector2(40f, 25f);
        public Vector2 StartOffset = new Vector2(0.9375f, -0.9375f);

        private void LateUpdate()
        {
            if (!Target) return;
            var position = transform.position;
            var delta = Target.position - position;
            var desired = position;
            if (Mathf.Abs(delta.x) > DeadZone.x) desired.x = Target.position.x - Mathf.Sign(delta.x) * DeadZone.x;
            if (Mathf.Abs(delta.y) > DeadZone.y) desired.y = Target.position.y - Mathf.Sign(delta.y) * DeadZone.y;
            transform.position = ClampAndSnap(desired);
        }

        public void SnapToTarget()
        {
            if (!Target) return;
            transform.position = ClampAndSnap(new Vector3(Target.position.x + StartOffset.x, Target.position.y + StartOffset.y, -10f));
        }

        private Vector3 ClampAndSnap(Vector3 position)
        {
            var camera = GetComponent<Camera>();
            var halfHeight = camera ? camera.orthographicSize : 9f;
            var halfWidth = halfHeight * (camera ? camera.aspect : 5f / 3f);
            position.x = Mathf.Clamp(position.x, halfWidth, Mathf.Max(halfWidth, LevelSize.x - halfWidth));
            position.y = Mathf.Clamp(position.y, Mathf.Min(-halfHeight, -LevelSize.y + halfHeight), -halfHeight);
            position.x = Mathf.Round(position.x * LevelRuntime.SourcePixelsPerTile) / LevelRuntime.SourcePixelsPerTile;
            position.y = Mathf.Round(position.y * LevelRuntime.SourcePixelsPerTile) / LevelRuntime.SourcePixelsPerTile;
            position.z = -10f;
            return position;
        }
    }
}

