﻿using UnityEngine;

namespace LethalMaze
{
    public sealed class ExitDoor : MonoBehaviour
    {
        private LevelRuntime level;
        public void Init(LevelRuntime runtime) => level = runtime;

        private void OnTriggerEnter2D(Collider2D other)
        {
            TryEnter(other);
        }

        private void OnTriggerStay2D(Collider2D other)
        {
            TryEnter(other);
        }

        private void TryEnter(Collider2D other)
        {
            if (!other.GetComponent<MoonPlayerController>()) return;
            level.TryWin();
        }
    }
}
