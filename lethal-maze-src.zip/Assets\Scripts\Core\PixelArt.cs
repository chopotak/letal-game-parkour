﻿using UnityEngine;

namespace LethalMaze
{
    public static class PixelArt
    {
        private static Sprite square;
        private static Sprite triangle;

        public static Sprite Square
        {
            get
            {
                if (square != null) return square;
                var texture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
                texture.filterMode = FilterMode.Point;
                texture.SetPixel(0, 0, Color.white);
                texture.Apply();
                square = Sprite.Create(texture, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1f);
                return square;
            }
        }

        public static GameObject Box(string name, Vector2 position, Vector2 size, Color color, Transform parent, string sortingLayer = "Default", int order = 0)
        {
            var obj = new GameObject(name);
            obj.transform.SetParent(parent, false);
            obj.transform.position = position;
            obj.transform.localScale = new Vector3(size.x, size.y, 1f);
            var renderer = obj.AddComponent<SpriteRenderer>();
            renderer.sprite = Square;
            renderer.color = color;
            renderer.sortingLayerName = sortingLayer;
            renderer.sortingOrder = order;
            return obj;
        }

        public static GameObject ChildBox(string name, Transform parent, Vector2 localPosition, Vector2 size, Color color, int order = 1)
        {
            var obj = new GameObject(name);
            obj.transform.SetParent(parent, false);
            obj.transform.localPosition = localPosition;
            obj.transform.localScale = new Vector3(size.x, size.y, 1f);
            var renderer = obj.AddComponent<SpriteRenderer>();
            renderer.sprite = Square;
            renderer.color = color;
            renderer.sortingOrder = order;
            return obj;
        }

        public static GameObject ChildTriangle(string name, Transform parent, Vector2 localPosition, Vector2 size, Color color, int order = 1)
        {
            var obj = new GameObject(name);
            obj.transform.SetParent(parent, false);
            obj.transform.localPosition = localPosition;
            obj.transform.localScale = new Vector3(size.x, size.y, 1f);
            var renderer = obj.AddComponent<SpriteRenderer>();
            renderer.sprite = Triangle;
            renderer.color = color;
            renderer.sortingOrder = order;
            return obj;
        }

        public static Sprite Triangle
        {
            get
            {
                if (triangle != null) return triangle;
                var texture = new Texture2D(16, 16, TextureFormat.RGBA32, false);
                texture.filterMode = FilterMode.Point;
                for (var y = 0; y < 16; y++)
                for (var x = 0; x < 16; x++)
                {
                    var halfWidth = y * 0.5f;
                    var inside = x >= 7.5f - halfWidth && x <= 7.5f + halfWidth;
                    texture.SetPixel(x, y, inside ? Color.white : Color.clear);
                }
                texture.Apply();
                triangle = Sprite.Create(texture, new Rect(0, 0, 16, 16), new Vector2(0.5f, 0f), 16f);
                return triangle;
            }
        }

        public static void AddWallDetails(GameObject obj)
        {
            ChildBox("Shadow lip", obj.transform, new Vector2(0.055f, -0.055f), new Vector2(1f, 1f), Hex("0A0D12"), -1);
            ChildBox("Top light", obj.transform, new Vector2(0f, 0.35f), new Vector2(0.82f, 0.08f), Hex("344961"), 2);
            ChildBox("Bottom dark", obj.transform, new Vector2(0f, -0.34f), new Vector2(0.75f, 0.07f), Hex("1A2534"), 2);
            ChildBox("Inset", obj.transform, new Vector2(-0.2f, 0.08f), new Vector2(0.36f, 0.06f), Hex("405873"), 2);
            ChildBox("Groove", obj.transform, new Vector2(0.2f, -0.08f), new Vector2(0.4f, 0.05f), Hex("111A27"), 2);
            ChildBox("Chip", obj.transform, new Vector2(0.31f, 0.18f), new Vector2(0.1f, 0.1f), Hex("1C2A3A"), 2);
        }

        public static void AddCatDetails(GameObject obj)
        {
            ChildBox("Body", obj.transform, new Vector2(0f, -0.08f), new Vector2(0.66f, 0.52f), Color.black, 5);
            ChildBox("Head", obj.transform, new Vector2(0f, 0.13f), new Vector2(0.72f, 0.48f), Color.black, 5);
            ChildTriangle("Left ear", obj.transform, new Vector2(-0.23f, 0.36f), new Vector2(0.2f, 0.24f), Color.black, 5);
            ChildTriangle("Right ear", obj.transform, new Vector2(0.23f, 0.36f), new Vector2(0.2f, 0.24f), Color.black, 5);
            ChildBox("Tail", obj.transform, new Vector2(-0.48f, -0.03f), new Vector2(0.3f, 0.16f), Color.black, 5);
            ChildBox("Eye L", obj.transform, new Vector2(-0.14f, 0.11f), new Vector2(0.06f, 0.14f), Hex("F7F2DF"), 6);
            ChildBox("Eye R", obj.transform, new Vector2(0.16f, 0.11f), new Vector2(0.06f, 0.14f), Hex("F7F2DF"), 6);
            ChildBox("Feet", obj.transform, new Vector2(0f, -0.39f), new Vector2(0.45f, 0.08f), Color.black, 5);
        }

        public static void AddSpikeDetails(GameObject obj)
        {
            var renderer = obj.GetComponent<SpriteRenderer>();
            if (renderer) renderer.color = Color.clear;
            ChildBox("Spike base shadow", obj.transform, new Vector2(0.02f, -0.18f), new Vector2(0.9f, 0.16f), Hex("182230"), 1);
            ChildBox("Spike base", obj.transform, new Vector2(0f, -0.15f), new Vector2(0.82f, 0.12f), Hex("26364A"), 2);
            for (var i = 0; i < 3; i++)
            {
                var x = -0.27f + i * 0.27f;
                ChildTriangle($"Spike {i}", obj.transform, new Vector2(x, -0.14f), new Vector2(0.25f, 0.46f), Hex("FF4C6A"), 3);
                ChildTriangle($"Spike shine {i}", obj.transform, new Vector2(x - 0.035f, -0.05f), new Vector2(0.06f, 0.22f), Hex("FFC0CB"), 4);
            }
        }

        public static void AddCoinDetails(GameObject obj)
        {
            var renderer = obj.GetComponent<SpriteRenderer>();
            if (renderer) renderer.color = Color.clear;
            ChildBox("Coin shadow", obj.transform, new Vector2(0.05f, -0.05f), new Vector2(0.36f, 0.48f), Hex("071014"), 1);
            ChildBox("Coin body", obj.transform, Vector2.zero, new Vector2(0.32f, 0.5f), Hex("FFD15C"), 2);
            ChildBox("Coin edge", obj.transform, new Vector2(0.12f, 0f), new Vector2(0.08f, 0.42f), Hex("B58322"), 3);
            ChildBox("Coin shine", obj.transform, new Vector2(-0.06f, 0.08f), new Vector2(0.08f, 0.18f), Hex("FFF0A6"), 4);
        }

        public static void AddDoorDetails(GameObject obj, Color color, bool locked)
        {
            var renderer = obj.GetComponent<SpriteRenderer>();
            if (renderer) renderer.color = color;
            ChildBox("Door shadow", obj.transform, new Vector2(0.05f, -0.05f), new Vector2(0.72f, 1.1f), Hex("05070A"), -1);
            ChildBox("Door highlight", obj.transform, new Vector2(-0.19f, 0.1f), new Vector2(0.12f, 0.72f), new Color(1f, 1f, 1f, 0.16f), 2);
            ChildBox("Door knob", obj.transform, new Vector2(0.18f, -0.05f), new Vector2(0.08f, 0.08f), locked ? Hex("FF4C6A") : Hex("071014"), 3);
        }

        public static void AddCoinGateDetails(GameObject obj)
        {
            var renderer = obj.GetComponent<SpriteRenderer>();
            if (renderer) renderer.color = Hex("FFD15C");
            ChildBox("Gate shadow", obj.transform, new Vector2(0.05f, -0.05f), new Vector2(1f, 1f), Hex("05070A"), -1);
            ChildBox("Gate slit 1", obj.transform, new Vector2(0f, 0.22f), new Vector2(0.52f, 0.08f), Hex("071014"), 3);
            ChildBox("Gate slit 2", obj.transform, new Vector2(0f, 0f), new Vector2(0.52f, 0.08f), Hex("071014"), 3);
            ChildBox("Gate slit 3", obj.transform, new Vector2(0f, -0.22f), new Vector2(0.52f, 0.08f), Hex("071014"), 3);
            ChildBox("Gate lock", obj.transform, new Vector2(0.23f, 0f), new Vector2(0.1f, 0.1f), Hex("FFF0A6"), 4);
        }

        public static void AddRobotDetails(GameObject obj)
        {
            var renderer = obj.GetComponent<SpriteRenderer>();
            if (renderer) renderer.color = Hex("7B8EA7");
            ChildBox("Robot shadow", obj.transform, new Vector2(0.05f, -0.05f), new Vector2(0.82f, 0.82f), Hex("071014"), -1);
            ChildBox("Robot top", obj.transform, new Vector2(0f, 0.22f), new Vector2(0.58f, 0.09f), Hex("B8C6D6"), 2);
            ChildBox("Robot eye", obj.transform, new Vector2(0.18f, 0.06f), new Vector2(0.13f, 0.16f), Hex("FFD15C"), 3);
            ChildBox("Robot grill", obj.transform, new Vector2(0f, -0.24f), new Vector2(0.5f, 0.08f), Hex("172232"), 3);
        }

        public static void AddFlierDetails(GameObject obj)
        {
            var renderer = obj.GetComponent<SpriteRenderer>();
            if (renderer) renderer.color = Hex("B583FF");
            ChildBox("Flier shadow", obj.transform, new Vector2(0.05f, -0.05f), new Vector2(0.72f, 0.72f), Hex("071014"), -1);
            ChildBox("Flier core", obj.transform, Vector2.zero, new Vector2(0.5f, 0.5f), Hex("B583FF"), 2);
            ChildBox("Flier eye L", obj.transform, new Vector2(-0.13f, 0.07f), new Vector2(0.07f, 0.1f), Hex("071014"), 3);
            ChildBox("Flier eye R", obj.transform, new Vector2(0.13f, 0.07f), new Vector2(0.07f, 0.1f), Hex("071014"), 3);
            ChildBox("Wing L", obj.transform, new Vector2(-0.38f, 0f), new Vector2(0.2f, 0.1f), Hex("52EADC"), 2);
            ChildBox("Wing R", obj.transform, new Vector2(0.38f, 0f), new Vector2(0.2f, 0.1f), Hex("52EADC"), 2);
        }

        public static void AddLaserCoreDetails(GameObject obj)
        {
            var renderer = obj.GetComponent<SpriteRenderer>();
            if (renderer) renderer.color = Hex("52EADC");
            ChildBox("Laser shadow", obj.transform, new Vector2(0.04f, -0.04f), new Vector2(0.42f, 0.42f), Hex("071014"), -1);
            ChildBox("Laser hole", obj.transform, Vector2.zero, new Vector2(0.16f, 0.16f), Hex("071014"), 2);
            ChildBox("Laser blink", obj.transform, new Vector2(0.01f, 0.01f), new Vector2(0.08f, 0.08f), Hex("F7F2DF"), 3);
        }

        public static Color Hex(string hex)
        {
            ColorUtility.TryParseHtmlString("#" + hex, out var color);
            return color;
        }
    }
}
