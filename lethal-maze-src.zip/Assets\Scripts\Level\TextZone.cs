﻿using UnityEngine;

namespace LethalMaze
{
    public sealed class TextZone : MonoBehaviour
    {
        private LevelRuntime level;
        private string message;

        public void Init(LevelRuntime runtime, string text)
        {
            level = runtime;
            message = text;
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            ShowIfPlayer(other);
        }

        private void OnTriggerStay2D(Collider2D other)
        {
            ShowIfPlayer(other);
        }

        private void ShowIfPlayer(Collider2D other)
        {
            if (other.GetComponent<MoonPlayerController>()) level.ShowMessage(message);
        }
    }
}
