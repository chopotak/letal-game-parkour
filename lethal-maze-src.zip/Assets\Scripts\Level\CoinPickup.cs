﻿using UnityEngine;

namespace LethalMaze
{
    public sealed class CoinPickup : MonoBehaviour
    {
        private LevelRuntime level;
        private bool taken;

        public void Init(LevelRuntime runtime) => level = runtime;

        private void OnTriggerEnter2D(Collider2D other)
        {
            TryCollect(other);
        }

        private void OnTriggerStay2D(Collider2D other)
        {
            TryCollect(other);
        }

        private void TryCollect(Collider2D other)
        {
            if (taken || !other.GetComponent<MoonPlayerController>()) return;
            taken = true;
            gameObject.SetActive(false);
            level.CollectCoin();
        }
    }
}
