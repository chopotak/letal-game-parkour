using UnityEngine;

namespace LethalMaze
{
    public sealed class PixelParticle : MonoBehaviour
    {
        private Vector2 velocity;
        private float life;
        private float maxLife;
        private SpriteRenderer spriteRenderer;

        public static void Burst(Vector2 worldPosition, Color color, int count, Transform parent)
        {
            for (var i = 0; i < count; i++)
            {
                var angle = Mathf.PI * 2f * i / Mathf.Max(1, count) + Random.value * 0.4f;
                var speed = (1.2f + Random.value * 3.7f) / LevelRuntime.SourcePixelsPerTile * 60f;
                var obj = PixelArt.Box("Particle", worldPosition, Vector2.one * ((2f + Random.value * 5f) / LevelRuntime.SourcePixelsPerTile), color, parent, "Default", 20);
                var particle = obj.AddComponent<PixelParticle>();
                particle.velocity = new Vector2(Mathf.Cos(angle), -Mathf.Sin(angle)) * speed;
                particle.life = 28f + Random.value * 24f;
                particle.maxLife = particle.life;
            }
        }

        private void Awake()
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
        }

        private void Update()
        {
            transform.position += (Vector3)(velocity * Time.deltaTime);
            velocity += Vector2.down * (0.08f * 3600f / LevelRuntime.SourcePixelsPerTile * Time.deltaTime);
            life -= 60f * Time.deltaTime;
            if (spriteRenderer)
            {
                var color = spriteRenderer.color;
                color.a = Mathf.Clamp01(life / Mathf.Max(1f, maxLife));
                spriteRenderer.color = color;
            }
            if (life <= 0f) Destroy(gameObject);
        }
    }
}
