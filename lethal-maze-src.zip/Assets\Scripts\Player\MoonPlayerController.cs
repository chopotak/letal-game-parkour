using UnityEngine;
using UnityEngine.InputSystem;

namespace LethalMaze
{
    public sealed class MoonPlayerController : MonoBehaviour
    {
        private const float StepSeconds = 1f / 60f;
        private const float PixelsPerTile = LevelRuntime.SourcePixelsPerTile;
        private static readonly Vector2 PlayerSize = new Vector2(LevelRuntime.PlayerWidth, LevelRuntime.PlayerHeight);

        [Header("Moon physics, same units as Unity tiles/second")]
        public float groundAcceleration = 3.54375f;
        public float airAcceleration = 11.34f;
        public float groundFriction = 0.965f;
        public float airFriction = 0.9994f;
        public float turnFriction = 0.995f;
        public float maxRunSpeed = 2.274f;
        public float maxHorizontalSpeed = 5.56875f;
        public float jumpVelocity = 5.896875f;
        public float jumpHoldForce = 4.8285f;
        public float jumpHoldEndForce = 1.998f;
        public int jumpHoldFrames = 124;
        public float jumpHoldDecay = 0.82f;
        public float jumpReleaseGravity = 1.647f;
        public float gravity = 8.235f;
        public float fastFallGravity = 7.32f;
        public float maxFallSpeed = 7.32f;
        public float wallJumpX = 5.34375f;
        public float wallJumpY = 5.224f;
        public float wallClimbJumpX = 0.7875f;
        public float wallClimbJumpY = 5.675f;
        public float wallJumpMomentumCarry = 0.72f;
        public float wallJumpAwayBoost = 0.65625f;
        public float wallGripFallSpeed = 0.103125f;
        public float wallSlideSpeed = 1.125f;
        public float wallFriction = 0.5f;
        public int wallGripFrames = 150;
        public int sameWallRelatchFrames = 24;
        public float wallLatchControlLockMs = 500f;

        private LevelRuntime level;
        private Rigidbody2D body;
        private BoxCollider2D box;
        private Vector2 spawnTopLeft;
        private Vector2 topLeft;
        private Vector2 velocity;
        private float accumulator;
        private float wallLatchLockTimer;
        private float wallImpactVelocityX;
        private int inputX;
        private int wallContactSide;
        private int wallContactFrames;
        private int wallJumpLockSide;
        private int wallJumpLockTimer;
        private int jumpHoldLeft;
        private int jumpHoldTotal;
        private bool grounded;
        private bool jumpHeld;
        private bool downHeld;
        private bool jumpQueued;
        private bool dead;
        private float respawnTimer;

        private Rect Bounds => new Rect(topLeft.x, topLeft.y, PlayerSize.x, PlayerSize.y);
        private Rect Hurtbox => new Rect(topLeft.x + 3f / PixelsPerTile, topLeft.y + 3f / PixelsPerTile, PlayerSize.x - 6f / PixelsPerTile, PlayerSize.y - 5f / PixelsPerTile);

        public Rect SimHurtbox => Hurtbox;

        private PlayerSpriteRenderer spriteRenderer;

        public void Init(LevelRuntime runtime, Vector2 spawnPosition)
        {
            level = runtime;
            spawnTopLeft = spawnPosition;
            topLeft = spawnTopLeft;
            // PixelArt visual details are replaced by PlayerSpriteRenderer
            spriteRenderer = GetComponent<PlayerSpriteRenderer>();
            if (spriteRenderer != null)
            {
                spriteRenderer.Facing = 1;
                spriteRenderer.Grounded = grounded;
                spriteRenderer.Alive = !dead;
            }
            SyncTransform();
        }

        private void Awake()
        {
            body = gameObject.AddComponent<Rigidbody2D>();
            body.bodyType = RigidbodyType2D.Kinematic;
            body.gravityScale = 0f;
            body.freezeRotation = true;
            body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            body.interpolation = RigidbodyInterpolation2D.Interpolate;

            var material = new PhysicsMaterial2D("Player No Friction") { friction = 0f, bounciness = 0f };
            body.sharedMaterial = material;
            box = gameObject.AddComponent<BoxCollider2D>();
            box.size = PlayerSize;
            box.sharedMaterial = material;
        }

        private void Update()
        {
            ReadInput();

            if (dead)
            {
                respawnTimer -= Time.deltaTime;
                if (respawnTimer <= 0f) level.ReloadAfterDeath();
                return;
            }

            accumulator += Mathf.Min(Time.deltaTime, 0.05f);
            while (accumulator >= StepSeconds)
            {
                Step();
                accumulator -= StepSeconds;
            }
            SyncTransform();
        }

        private void ReadInput()
        {
            var keyboard = Keyboard.current;
            if (keyboard == null) return;

            if (keyboard.rKey.wasPressedThisFrame) level.ReloadLevel();

            inputX = (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed ? 1 : 0)
                - (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed ? 1 : 0);
            jumpHeld = keyboard.spaceKey.isPressed || keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed;
            downHeld = keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed;

            if (keyboard.spaceKey.wasPressedThisFrame || keyboard.wKey.wasPressedThisFrame || keyboard.upArrowKey.wasPressedThisFrame)
            {
                jumpQueued = true;
            }
        }

        private void Step()
        {
            var touchingWall = 0;
            var horizontalInput = inputX;

            if (wallLatchLockTimer > 0f) wallLatchLockTimer = Mathf.Max(0f, wallLatchLockTimer - StepSeconds * 1000f);
            if (wallJumpLockTimer > 0)
            {
                wallJumpLockTimer -= 1;
                if (wallJumpLockTimer == 0) wallJumpLockSide = 0;
            }

            var acceleration = grounded ? groundAcceleration : airAcceleration;
            if (horizontalInput != 0 && velocity.x * horizontalInput < 0f) velocity.x *= turnFriction;
            if (horizontalInput != 0) velocity.x += horizontalInput * acceleration * StepSeconds;
            else velocity.x *= grounded ? groundFriction : airFriction;
            velocity.x = Mathf.Clamp(velocity.x, -maxHorizontalSpeed, maxHorizontalSpeed);
            if (grounded) velocity.x = Mathf.Clamp(velocity.x, -maxRunSpeed, maxRunSpeed);

            if (jumpQueued)
            {
                if (grounded)
                {
                    StartJump();
                }
                else if (wallContactSide != 0)
                {
                    StartWallJump();
                }
                jumpQueued = false;
            }

            velocity.y += gravity * StepSeconds;
            ApplyJumpHold();
            if (!jumpHeld && velocity.y < -PixelsToTilesPerSecond(1f)) velocity.y += jumpReleaseGravity * StepSeconds;

            topLeft.x += velocity.x * StepSeconds;
            touchingWall = ResolveAxis(true, touchingWall);

            if (touchingWall != 0 && touchingWall == -wallJumpLockSide) wallJumpLockSide = 0;
            if (touchingWall == 0 && wallContactSide != 0 && IsStillTouchingWall(wallContactSide)) touchingWall = wallContactSide;

            ApplyWallSlide(touchingWall);

            if (downHeld && !grounded && velocity.y > -PixelsToTilesPerSecond(1f)) velocity.y += fastFallGravity * StepSeconds;
            velocity.y = Mathf.Min(maxFallSpeed, velocity.y);

            grounded = false;
            topLeft.y += velocity.y * StepSeconds;
            ResolveAxis(false, touchingWall);

            if (grounded)
            {
                wallContactSide = 0;
                wallContactFrames = 0;
                wallJumpLockSide = 0;
                wallJumpLockTimer = 0;
                wallLatchLockTimer = 0f;
                wallImpactVelocityX = 0f;
                jumpHoldLeft = 0;
                jumpHoldTotal = 0;
            }
        }

        private void StartJump()
        {
            velocity.y = -jumpVelocity;
            grounded = false;
            jumpHoldLeft = jumpHoldFrames;
            jumpHoldTotal = jumpHoldFrames;
            level.BurstWorld(transform.position + Vector3.down * 0.35f, PixelArt.Hex("B8C6D6"), 8);
        }

        private void StartWallJump()
        {
            var jumpSide = wallContactSide;
            var outward = -jumpSide;
            var holdingAway = (jumpSide == 1 && inputX < 0) || (jumpSide == -1 && inputX > 0);
            var holdingToward = (jumpSide == 1 && inputX > 0) || (jumpSide == -1 && inputX < 0);
            var impactCarry = Mathf.Max(0f, wallImpactVelocityX * jumpSide) * wallJumpMomentumCarry;

            if (holdingToward && !holdingAway)
            {
                velocity.x = outward * wallClimbJumpX;
                velocity.y = -wallClimbJumpY;
            }
            else
            {
                var outwardImpulse = wallJumpX + impactCarry;
                if (holdingAway) outwardImpulse += wallJumpAwayBoost;
                velocity.x = velocity.x * wallJumpMomentumCarry + outward * outwardImpulse;
                velocity.y = -wallJumpY;
            }

            grounded = false;
            jumpHoldLeft = Mathf.RoundToInt(jumpHoldFrames * 0.65f);
            jumpHoldTotal = jumpHoldLeft;
            wallJumpLockSide = jumpSide;
            wallJumpLockTimer = sameWallRelatchFrames;
            wallLatchLockTimer = 0f;
            wallContactFrames = 0;
            wallContactSide = 0;
            wallImpactVelocityX = 0f;
            level.BurstWorld(transform.position, PixelArt.Hex("B8C6D6"), 8);
        }

        private void ApplyJumpHold()
        {
            if (!jumpHeld)
            {
                jumpHoldLeft = 0;
                jumpHoldTotal = 0;
                return;
            }
            if (jumpHoldLeft <= 0 || velocity.y >= 0f || jumpHoldForce <= 0f) return;

            var total = Mathf.Max(1, jumpHoldTotal);
            var remaining = Mathf.Clamp01(jumpHoldLeft / (float)total);
            var holdForce = jumpHoldEndForce + (jumpHoldForce - jumpHoldEndForce) * Mathf.Pow(remaining, jumpHoldDecay);
            velocity.y -= holdForce * StepSeconds;
            jumpHoldLeft -= 1;
        }

        private void ApplyWallSlide(int touchingWall)
        {
            var side = touchingWall != 0 ? touchingWall : (wallLatchLockTimer > 0f ? wallContactSide : 0);
            var continuingSameLatch = side != 0 && wallContactSide == side;
            if (side != 0 && side == wallJumpLockSide && !continuingSameLatch)
            {
                wallContactSide = 0;
                wallContactFrames = 0;
                return;
            }

            if (grounded || side == 0 || velocity.y < 0f)
            {
                if (side == 0 && wallLatchLockTimer <= 0f)
                {
                    wallContactSide = 0;
                    wallContactFrames = 0;
                }
                return;
            }

            if (downHeld)
            {
                wallContactSide = 0;
                wallContactFrames = 0;
                wallLatchLockTimer = 0f;
                return;
            }

            var holdingToward = (side == -1 && inputX < 0) || (side == 1 && inputX > 0);
            var pressingAway = (side == -1 && inputX > 0) || (side == 1 && inputX < 0);
            if (!holdingToward && wallLatchLockTimer <= 0f)
            {
                wallContactFrames = 0;
                wallContactSide = 0;
                return;
            }
            if (pressingAway && wallContactFrames > wallGripFrames && wallLatchLockTimer <= 0f)
            {
                wallContactFrames = 0;
                wallContactSide = 0;
                return;
            }

            if (wallContactSide != side)
            {
                wallContactSide = side;
                wallContactFrames = 0;
                wallLatchLockTimer = wallLatchControlLockMs;
            }

            wallContactFrames += 1;
            var maxSlide = wallContactFrames > wallGripFrames ? wallSlideSpeed : wallGripFallSpeed;
            if (velocity.y > maxSlide) velocity.y = wallFriction > 0f ? maxSlide + (velocity.y - maxSlide) * wallFriction : maxSlide;
        }

        private int ResolveAxis(bool horizontal, int touchingWall)
        {
            var bounds = Bounds;
            foreach (var tile in level.SolidRectsNear(bounds))
            {
                if (!Overlaps(bounds, tile)) continue;

                if (horizontal)
                {
                    if (velocity.x > 0f)
                    {
                        topLeft.x = tile.xMin - PlayerSize.x;
                        wallImpactVelocityX = velocity.x;
                        touchingWall = 1;
                    }
                    else if (velocity.x < 0f)
                    {
                        topLeft.x = tile.xMax;
                        wallImpactVelocityX = velocity.x;
                        touchingWall = -1;
                    }
                    velocity.x = 0f;
                }
                else
                {
                    if (velocity.y > 0f)
                    {
                        topLeft.y = tile.yMin - PlayerSize.y;
                        grounded = true;
                    }
                    else if (velocity.y < 0f)
                    {
                        topLeft.y = tile.yMax;
                    }
                    velocity.y = 0f;
                }

                bounds = Bounds;
            }
            return touchingWall;
        }

        private bool IsStillTouchingWall(int side)
        {
            var probe = new Rect(topLeft.x + side / PixelsPerTile, topLeft.y + 3f / PixelsPerTile, PlayerSize.x, PlayerSize.y - 6f / PixelsPerTile);
            foreach (var tile in level.SolidRectsNear(probe))
            {
                if (Overlaps(probe, tile)) return true;
            }
            return false;
        }

        private void SyncTransform()
        {
            var position = LevelRuntime.SimToWorldCenter(topLeft, PlayerSize);
            if (body) body.position = position;
            transform.position = position;
            if (spriteRenderer != null)
            {
                // update renderer state
                if (Mathf.Abs(velocity.x) > 0.01f)
                {
                    spriteRenderer.Facing = velocity.x > 0f ? 1 : -1;
                }
                spriteRenderer.Grounded = grounded;
                spriteRenderer.Alive = !dead;
            }
        }

        public void Die()
        {
            if (dead) return;
            dead = true;
            respawnTimer = 0.56f;
            velocity = Vector2.zero;
            level.PlayerDied();
        }

        public void Respawn()
        {
            dead = false;
            respawnTimer = 0f;
            topLeft = spawnTopLeft;
            velocity = Vector2.zero;
            grounded = false;
            wallContactSide = 0;
            wallContactFrames = 0;
            wallJumpLockSide = 0;
            wallJumpLockTimer = 0;
            wallLatchLockTimer = 0f;
            wallImpactVelocityX = 0f;
            jumpHoldLeft = 0;
            jumpHoldTotal = 0;
            jumpQueued = false;
            accumulator = 0f;
            SyncTransform();
        }

        private static float PixelsToTilesPerSecond(float pixelsPerFrame)
        {
            return pixelsPerFrame * 60f / PixelsPerTile;
        }

        private static bool Overlaps(Rect a, Rect b)
        {
            return a.xMin < b.xMax && a.xMax > b.xMin && a.yMin < b.yMax && a.yMax > b.yMin;
        }
    }
}
